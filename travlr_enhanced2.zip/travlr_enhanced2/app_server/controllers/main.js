/**
 * Renders the homepage for Travlr Getaways.
 * @param {import('express').Request} req Express request object
 * @param {import('express').Response} res Express response object
 */
const index = (req, res) => {
    res.render('index', { title: 'Travlr Getaways', currentPath: '/travel'});
};

module.exports = {
    index
};
