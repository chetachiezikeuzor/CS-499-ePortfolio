/**
 * Authentication middleware for protected/admin routes.
 * Validates JWT tokens and checks for admin privileges.
 */

const jwt = require('jsonwebtoken');
const { STATUS, ERRORS } = require('../constants');
const logger = require('../logger'); // Use Winston for all logging

/**
 * Middleware to require a valid JWT token for protected routes.
 */
const requireAuth = (req, res, next) => {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) {
        logger.warn('Unauthorized: Missing token');
        return res.status(STATUS.UNAUTHORIZED).json({ message: ERRORS.UNAUTHORIZED });
    }
    try {
        if (!process.env.JWT_SECRET) throw new Error('JWT_SECRET not set in environment');
        req.user = jwt.verify(token, process.env.JWT_SECRET);
        next();
    } catch (err) {
        logger.warn(`Unauthorized: ${err.message}`);
        return res.status(STATUS.UNAUTHORIZED).json({ message: ERRORS.UNAUTHORIZED });
    }
};

/**
 * Middleware to require the user to have 'admin' role for certain routes.
 */
const requireAdmin = (req, res, next) => {
    if (req.user?.role !== 'admin') {
        logger.warn('Forbidden: Non-admin tried to access admin route');
        return res.status(STATUS.FORBIDDEN).json({ message: ERRORS.FORBIDDEN });
    }
    next();
};

module.exports = { requireAuth, requireAdmin };
