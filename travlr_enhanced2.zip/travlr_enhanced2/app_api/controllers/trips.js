/**
 * Trip API controller for the Travlr application.
 * Performs CRUD operations with validation, role checks, logging,
 * pagination, sorting, and cost calculation.
 */

const express = require('express');
const router = express.Router();
const Trip = require('../models/travlr');
const { validateTrip } = require('../middleware/validate');
const { requireAuth, requireAdmin } = require('../middleware/auth');
const { STATUS, ERRORS } = require('../constants');
const logger = require('../logger');
const { handleServerError } = require('../utils/errorHandlers');
const {
    sanitizeQueryParam,
    sanitizeTripPayload,
    sanitizeString
} = require('../utils/sanitizers');

// Whitelist of fields that may be used for sorting (must match indexed fields in schema)
const ALLOWED_SORT_FIELDS = new Set([
    'code',
    'name',
    'length',
    'start',
    'resort',
    'perPerson',
    'createdAt',
    'updatedAt'
]);

/**
 * @route   GET /trips
 * @desc    Retrieve all trips with pagination and sorting
 * @access  Public
 */
router.get('/', async (req, res) => {
    console.time('[Trips] fetch all');
    try {
        // Sanitize query parameters (page, limit, sortBy)
        const rawPage = req.query.page;
        const rawLimit = req.query.limit;
        const rawSortBy = req.query.sortBy;

        const page = sanitizeQueryParam(rawPage, 1);
        const limit = sanitizeQueryParam(rawLimit, 10);

        // Whitelist sortBy, default to "name"
        let sortBy = 'name';
        if (typeof rawSortBy === 'string') {
            const candidate = sanitizeString(rawSortBy);
            if (ALLOWED_SORT_FIELDS.has(candidate)) {
                sortBy = candidate;
            }
        }

        // Count total documents for pagination metadata
        const totalTrips = await Trip.countDocuments({});

        // Fetch paginated, sorted results (use .lean() for performance)
        const trips = await Trip.find({})
            .sort({ [sortBy]: 1 })
            .skip((page - 1) * limit)
            .limit(limit)
            .lean();

        if (!trips.length) {
            logger.info('No trips found');
            console.timeEnd('[Trips] fetch all');
            return res.status(STATUS.NOT_FOUND).json({
                success: false,
                message: ERRORS.TRIP_NOT_FOUND
            });
        }

        console.timeEnd('[Trips] fetch all');
        return res.status(STATUS.OK).json({
            success: true,
            data: {
                page,
                totalPages: Math.ceil(totalTrips / limit),
                totalTrips,
                trips
            }
        });
    } catch (err) {
        console.timeEnd('[Trips] fetch all');
        return handleServerError(res, err, 'Fetching all trips');
    }
});

/**
 * @route   GET /trips/:tripCode
 * @desc    Retrieve a specific trip by code
 * @access  Public
 */
router.get('/:tripCode', async (req, res) => {
    const tripCode = sanitizeString(req.params.tripCode);
    console.time(`[Trips] fetch one: ${tripCode}`);
    try {
        // .lean() for faster read
        const trip = await Trip.findOne({ code: tripCode }).lean();
        if (!trip) {
            logger.info(`Trip not found: ${tripCode}`);
            console.timeEnd(`[Trips] fetch one: ${tripCode}`);
            return res.status(STATUS.NOT_FOUND).json({
                success: false,
                message: ERRORS.TRIP_NOT_FOUND
            });
        }

        console.timeEnd(`[Trips] fetch one: ${tripCode}`);
        return res.status(STATUS.OK).json({
            success: true,
            data: trip
        });
    } catch (err) {
        console.timeEnd(`[Trips] fetch one: ${tripCode}`);
        return handleServerError(res, err, `Fetching trip with code ${tripCode}`);
    }
});

/**
 * @route   GET /trips/:tripCode/cost/:groupSize
 * @desc    Calculate total cost for a group
 * @access  Public
 */
router.get('/:tripCode/cost/:groupSize', async (req, res) => {
    const tripCode = sanitizeString(req.params.tripCode);
    const rawGroupSize = req.params.groupSize;
    console.time(`[Trips] calc cost: ${tripCode}`);
    try {
        const trip = await Trip.findOne({ code: tripCode }).lean();
        if (!trip) {
            logger.info(`Trip not found: ${tripCode}`);
            console.timeEnd(`[Trips] calc cost: ${tripCode}`);
            return res.status(STATUS.NOT_FOUND).json({
                success: false,
                message: ERRORS.TRIP_NOT_FOUND
            });
        }

        // Validate groupSize
        const size = parseInt(rawGroupSize, 10);
        if (isNaN(size) || size <= 0) {
            console.timeEnd(`[Trips] calc cost: ${tripCode}`);
            return res.status(STATUS.BAD_REQUEST).json({
                success: false,
                message: 'Group size must be a positive integer.'
            });
        }

        // Calculate total cost using model field directly
        const totalCost = trip.perPerson * size;

        console.timeEnd(`[Trips] calc cost: ${tripCode}`);
        return res.status(STATUS.OK).json({
            success: true,
            data: {
                tripCode,
                groupSize: size,
                costPerPerson: trip.perPerson,
                totalCost
            }
        });
    } catch (err) {
        console.timeEnd(`[Trips] calc cost: ${tripCode}`);
        return handleServerError(res, err, `Calculating group cost for ${tripCode}`);
    }
});

/**
 * @route   POST /trips
 * @desc    Create a new trip (Admin only)
 * @access  Private
 */
router.post(
    '/',
    requireAuth,
    requireAdmin,
    validateTrip,
    async (req, res) => {
        console.time('[Trips] create');
        try {
            // Sanitize entire payload
            const sanitized = sanitizeTripPayload(req.body);
            const { code } = sanitized;

            // Enforce unique trip code
            const existingTrip = await Trip.findOne({ code }).lean();
            if (existingTrip) {
                logger.warn(`Trip creation failed: Duplicate code ${code}`);
                console.timeEnd('[Trips] create');
                return res.status(STATUS.BAD_REQUEST).json({
                    success: false,
                    message: ERRORS.DUPLICATE_CODE
                });
            }

            // Save new trip
            const newTrip = new Trip(sanitized);
            await newTrip.save();

            logger.info(`Trip created: ${newTrip.code}`);
            console.timeEnd('[Trips] create');
            return res.status(STATUS.CREATED).json({
                success: true,
                data: newTrip
            });
        } catch (err) {
            console.timeEnd('[Trips] create');
            return handleServerError(res, err, 'Creating trip');
        }
    }
);

/**
 * @route   PUT /trips/:tripCode
 * @desc    Update a trip by code (Admin only)
 * @access  Private
 */
router.put(
    '/:tripCode',
    requireAuth,
    requireAdmin,
    validateTrip,
    async (req, res) => {
        const tripCode = sanitizeString(req.params.tripCode);
        console.time(`[Trips] update: ${tripCode}`);
        try {
            // Sanitize updated fields
            const sanitized = sanitizeTripPayload(req.body);

            const updatedTrip = await Trip.findOneAndUpdate(
                { code: tripCode },
                sanitized,
                {
                    new: true,
                    runValidators: true
                }
            ).lean();

            if (!updatedTrip) {
                logger.info(`Update failed: Trip not found - ${tripCode}`);
                console.timeEnd(`[Trips] update: ${tripCode}`);
                return res.status(STATUS.NOT_FOUND).json({
                    success: false,
                    message: ERRORS.TRIP_NOT_FOUND
                });
            }

            logger.info(`Trip updated: ${updatedTrip.code}`);
            console.timeEnd(`[Trips] update: ${tripCode}`);
            return res.status(STATUS.OK).json({
                success: true,
                data: updatedTrip
            });
        } catch (err) {
            console.timeEnd(`[Trips] update: ${tripCode}`);
            return handleServerError(res, err, `Updating trip with code ${tripCode}`);
        }
    }
);

/**
 * @route   DELETE /trips/:tripCode
 * @desc    Delete a trip by code (Admin only)
 * @access  Private
 */
router.delete('/:tripCode', requireAuth, requireAdmin, async (req, res) => {
    const tripCode = sanitizeString(req.params.tripCode);
    console.time(`[Trips] delete: ${tripCode}`);
    try {
        const deletedTrip = await Trip.findOneAndDelete({ code: tripCode }).lean();
        if (!deletedTrip) {
            logger.info(`Deletion failed: Trip not found - ${tripCode}`);
            console.timeEnd(`[Trips] delete: ${tripCode}`);
            return res.status(STATUS.NOT_FOUND).json({
                success: false,
                message: ERRORS.TRIP_NOT_FOUND
            });
        }

        logger.info(`Trip deleted: ${deletedTrip.code}`);
        console.timeEnd(`[Trips] delete: ${tripCode}`);
        return res.status(STATUS.OK).json({
            success: true,
            message: `Trip ${deletedTrip.code} successfully deleted.`
        });
    } catch (err) {
        console.timeEnd(`[Trips] delete: ${tripCode}`);
        return handleServerError(res, err, `Deleting trip with code ${tripCode}`);
    }
});

module.exports = router;