/**
 * Express router for user authentication (register/login) for Travlr Getaways.
 * Provides secure registration and login using bcrypt and JWT.
 */

const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

const { validateRegister } = require('../middleware/validate');
const { sanitizeRegisterFields } = require('../middleware/sanitizers');
const User = require('../models/user');
const logger = require('../logger');
const { STATUS, ERRORS } = require('../constants');

/**
 * @typedef {Object} AuthRequestBody
 * @property {string} name
 * @property {string} email
 * @property {string} password
 */

/**
 * @route   POST /auth/register
 * @desc    Register a new user
 * @access  Public
 */
router.post(
    '/register',
    sanitizeRegisterFields, // Step 1: sanitize name/email
    validateRegister,       // Step 2: validate registration fields
    async (req, res) => {
        try {
            const { name, email, password } = req.body;

            // Check if user already exists (lean() for performance)
            const existing = await User.findOne({ email }).lean();
            if (existing) {
                logger.warn(`Registration attempt for existing user: ${email}`);
                return res.status(STATUS.BAD_REQUEST).json({
                    success: false,
                    message: ERRORS.USER_EXISTS
                });
            }

            // Hash password
            const hashedPassword = await bcrypt.hash(password, 12);

            // Create new user
            const user = new User({
                name,
                email,
                password: hashedPassword,
                role: 'user'
            });
            await user.save();

            // Ensure JWT_SECRET is set
            if (!process.env.JWT_SECRET) {
                throw new Error('JWT_SECRET not set in environment');
            }

            // Generate JWT (expires in 1 day)
            const token = jwt.sign(
                { id: user._id, role: user.role },
                process.env.JWT_SECRET,
                { expiresIn: '1d' }
            );

            logger.info(`New user registered: ${email}`);
            return res.status(STATUS.CREATED).json({
                success: true,
                data: { token }
            });
        } catch (err) {
            logger.error('Registration error:', err);
            return res.status(STATUS.SERVER_ERROR).json({
                success: false,
                message: ERRORS.SERVER
            });
        }
    }
);

/**
 * @route   POST /auth/login
 * @desc    Authenticate user & return JWT
 * @access  Public
 */
router.post('/login', async (req, res) => {
    let { email, password } = req.body;

    // Basic presence check
    if (!email || !password) {
        return res.status(STATUS.BAD_REQUEST).json({
            success: false,
            message: ERRORS.FIELDS_REQUIRED
        });
    }

    // Sanitize login email
    email = typeof email === 'string' ? email.trim().toLowerCase() : '';

    try {
        // Lookup user by sanitized email
        const user = await User.findOne({ email }).lean();
        if (!user) {
            logger.warn(`Login failed: user not found (${email})`);
            return res.status(STATUS.BAD_REQUEST).json({
                success: false,
                message: ERRORS.INVALID_CREDENTIALS
            });
        }

        // Compare password
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            logger.warn(`Login failed: invalid password for ${email}`);
            return res.status(STATUS.BAD_REQUEST).json({
                success: false,
                message: ERRORS.INVALID_CREDENTIALS
            });
        }

        // Ensure JWT_SECRET is set
        if (!process.env.JWT_SECRET) {
            throw new Error('JWT_SECRET not set in environment');
        }

        // Generate JWT (expires in 1 day)
        const token = jwt.sign(
            { id: user._id, role: user.role },
            process.env.JWT_SECRET,
            { expiresIn: '1d' }
        );

        logger.info(`User logged in: ${email}`);
        return res.status(STATUS.OK).json({
            success: true,
            data: { token }
        });
    } catch (err) {
        logger.error('Login error:', err);
        return res.status(STATUS.SERVER_ERROR).json({
            success: false,
            message: ERRORS.SERVER
        });
    }
});

module.exports = router;