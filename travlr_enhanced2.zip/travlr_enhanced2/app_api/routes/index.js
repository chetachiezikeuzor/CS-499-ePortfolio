/**
 * API routes for Travlr Getaways backend.
 * Includes trip CRUD endpoints and authentication.
 * Middleware enforces admin access and validation.
 */
const express = require('express');
const router = express.Router();

// Import routers
const tripsRouter = require('../controllers/trips');
const authRouter = require('../controllers/authentication');

// Mount routers under /trips and /auth paths
router.use('/trips', tripsRouter);
router.use('/auth', authRouter);

// Root endpoint (optional)
router.get('/', (req, res) => res.json({ message: 'Welcome to Travlr API!' }));

module.exports = router;

