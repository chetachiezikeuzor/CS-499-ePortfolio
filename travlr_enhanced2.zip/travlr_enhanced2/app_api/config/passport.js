/**
 * Configures Passport.js local authentication strategy for Travlr Getaways.
 * Uses the 'email' field as the username and validates users against MongoDB.
 * Passwords are verified with bcrypt hash comparison.
 */
const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const User = require('../models/user');
const { ERRORS } = require('../constants');


passport.use(new LocalStrategy(
    {
        usernameField: 'email'
    },
    /**
     * Passport local authentication strategy.
     * Finds the user by email and checks the password using bcrypt.
     * @param {string} username User's email address
     * @param {string} password User's plain text password
     * @param {Function} done Passport callback
     */
    async (username, password, done) => {
        try {
            const user = await User.findOne({ email: username });
            if (!user) {
                return done(null, false, { message: ERRORS.INVALID_EMAIL });
            }
            // Use bcrypt to check hashed password
            const isMatch = await bcrypt.compare(password, user.password);
            if (!isMatch) {
                return done(null, false, { message: ERRORS.INVALID_PASSWORD });
            }
            return done(null, user);
        } catch (err) {
            return done(err);
        }
    }
));
