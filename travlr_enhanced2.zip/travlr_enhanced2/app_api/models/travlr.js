/**
 * Mongoose schema and model for trips in Travlr Getaways.
 * Each trip has a unique code, name, length, start date, resort,
 * perPerson cost, image, and description.  This model enforces strict
 * validation and a unique constraint on trip codes.
 */

const mongoose = require('mongoose');

// Schema definition for a trip
const tripSchema = new mongoose.Schema({
    code: {
        type: String,
        required: [true, 'Trip code is required.'],
        unique: true,
        index: true
    },
    name: {
        type: String,
        required: [true, 'Trip name is required.'],
        index: true
    },
    length: {
        type: Number,
        required: [true, 'Trip length is required.'],
        min: [1, 'Trip length must be at least 1 day.']
    },
    start: {
        type: Date,
        required: [true, 'Start date is required.']
    },
    resort: {
        type: String,
        required: [true, 'Resort is required.']
    },
    perPerson: {
        type: Number,
        required: [true, 'Per person cost is required.'],
        min: [0, 'Per person cost must be non‐negative.']
    },
    image: {
        type: String,
        required: [true, 'Image URL is required.']
    },
    description: {
        type: String,
        required: [true, 'Trip description is required.']
    }
}, {
    timestamps: true // Adds createdAt and updatedAt fields automatically
});

/**
 * Instance method to calculate total cost for a given group size.
 * Ceil/floor logic could be added as needed; here we do a simple multiply.
 * @param {number} groupSize
 * @returns {number} total cost
 */
tripSchema.methods.calculateCost = function (groupSize) {
    return this.perPerson * groupSize;
};

// Export the Trip model, using the collection "trips"
const Trip = mongoose.model('Trip', tripSchema, 'trips');
module.exports = Trip;
