/**
 * Mongoose User model for Travlr Getaways.
 * The `password` field contains a bcrypt hash. Plaintext passwords are never stored.
 * Provides an instance method to generate a signed JWT.
 */

const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');
const validator = require('validator');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema(
    {
        email: {
            type: String,
            required: [true, 'Email is required.'],
            unique: true,
            index: true,
            lowercase: true,
            trim: true,
            validate: {
                validator(value) {
                    return validator.isEmail(value);
                },
                message: 'Must be a valid email address.'
            }
        },
        name: {
            type: String,
            required: [true, 'Name is required.'],
            trim: true,
            minlength: [2, 'Name must be at least 2 characters.'],
            maxlength: [50, 'Name must be at most 50 characters.']
        },
        password: {
            type: String,
            required: [true, 'Password is required.'],
            minlength: [8, 'Password must be at least 8 characters long.'],
            // We never store plaintext; hashing is done in pre‐save hook
        },
        role: {
            type: String,
            enum: ['user', 'admin'],
            default: 'user'
        }
    },
    {
        timestamps: true
    }
);

// Pre‐save hook: hash password if it was modified (or new)
userSchema.pre('save', async function (next) {
    if (!this.isModified('password')) return next();
    try {
        // Salt rounds = 12 (sufficient for production)
        const salt = await bcrypt.genSalt(12);
        this.password = await bcrypt.hash(this.password, salt);
        return next();
    } catch (err) {
        return next(err);
    }
});

/**
 * Instance method to compare a plaintext password with the stored hash.
 * @param {string} plaintext
 * @returns {Promise<boolean>}
 */
userSchema.methods.comparePassword = async function (plaintext) {
    return await bcrypt.compare(plaintext, this.password);
};

/**
 * Generates a signed JWT token for the user.
 * Payload includes: user _id, email, name, role, and expiration.
 * Expires in 7 days by default.
 * @returns {string} JWT token
 */
userSchema.methods.generateJwt = function () {
    if (!process.env.JWT_SECRET) {
        throw new Error('JWT_SECRET not set in environment');
    }
    const expiresIn = '7d'; // 7 days
    return jwt.sign(
        {
            _id: this._id,
            email: this.email,
            name: this.name,
            role: this.role
        },
        process.env.JWT_SECRET,
        { expiresIn }
    );
};

// Index on email for fast lookups & unique constraint
userSchema.index({ email: 1 }, { unique: true });

const User = mongoose.model('User', userSchema);
module.exports = User;