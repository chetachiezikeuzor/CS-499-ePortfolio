/**
 * Winston-based logger for production-ready logging.
 * - Logs to Console by default; can add File transports as needed.
 */

const { createLogger, format, transports } = require('winston');

// Determine log level based on environment
const level = process.env.NODE_ENV === 'production' ? 'info' : 'debug';

const logger = createLogger({
    level,
    format: format.combine(
        format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
        format.errors({ stack: true }), // include stack trace
        format.splat(),
        format.json()
    ),
    defaultMeta: { service: 'travlr-service' },
    transports: [
        new transports.Console({
            format: format.combine(
                format.colorize(),
                format.simple()
            )
        })
    ]
});

module.exports = logger;
