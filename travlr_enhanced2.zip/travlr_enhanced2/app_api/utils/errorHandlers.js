/**
 * Utility function to handle unexpected errors in a consistent way.
 */

const { STATUS, ERRORS } = require('../constants');
const logger = require('../logger');

/**
 * Generic server error handler
 *
 * Logs the error at “error” level (with stack trace if available),
 * and sends a 500 response with a standard JSON payload.
 *
 * @param {import('express').Response} res - Express response object
 * @param {Error} error - The error thrown
 * @param {string} context - Description of where the error occurred
 * @returns {import('express').Response} HTTP response with error message
 */
const handleServerError = (res, error, context = 'Unknown Context') => {
    // Log full error and context
    logger.error(`✖︎ [${context}] failed: ${error.message}`, {
        stack: error.stack || null,
        context: context
    });

    return res.status(STATUS.SERVER_ERROR).json({
        success: false,
        message: ERRORS.SERVER
    });
};

module.exports = { handleServerError };