/**
 * Uses validator.js and sanitize-html to:
 *  - Trim and escape untrusted strings
 *  - Normalize emails
 *  - Convert/validate numbers and dates
 *  - Whitelist basic HTML in descriptions
 */

const validator = require('validator');
const sanitizeHtml = require('sanitize-html');

/**
 * sanitizeString
 *  - Trims whitespace
 *  - Escapes special characters to prevent XSS
 *
 * @param {any} input
 * @returns {string} sanitized string (or empty string if invalid)
 */
function sanitizeString(input) {
    if (typeof input !== 'string') {
        return '';
    }
    // Remove leading/trailing whitespace
    const trimmed = validator.trim(input);
    // Escape anything potentially dangerous
    return validator.escape(trimmed);
}

/**
 * sanitizeEmail
 *  - Trims whitespace
 *  - Validates as email
 *  - Normalizes (lowercase, etc.)
 *
 * @param {any} email
 * @returns {string} normalized email or empty string if invalid
 */
function sanitizeEmail(email) {
    if (typeof email !== 'string') {
        return '';
    }
    const trimmed = validator.trim(email);
    if (!validator.isEmail(trimmed)) {
        return '';
    }
    return validator.normalizeEmail(trimmed);
}

/**
 * sanitizeNumber
 *  - Attempts to convert input to a Number
 *  - Returns null if invalid
 *
 * @param {string|number} input
 * @returns {number|null}
 */
function sanitizeNumber(input) {
    if (typeof input === 'number') {
        return Number.isFinite(input) ? input : null;
    }
    if (typeof input !== 'string') {
        return null;
    }
    const trimmed = validator.trim(input);
    // Only allow numeric characters (no currency symbols)
    if (!validator.isNumeric(trimmed, { no_symbols: true })) {
        return null;
    }
    const num = Number(trimmed);
    return Number.isFinite(num) ? num : null;
}

/**
 * sanitizeDate
 *  - Converts an ISO8601‐like string to a Date object
 *  - Returns null if invalid
 *
 * @param {string|Date} input
 * @returns {Date|null}
 */
function sanitizeDate(input) {
    if (input instanceof Date) {
        // Already a Date object; check validity
        return isNaN(input.getTime()) ? null : input;
    }
    if (typeof input !== 'string') {
        return null;
    }
    const trimmed = validator.trim(input);
    if (!validator.isISO8601(trimmed)) {
        return null;
    }
    const date = new Date(trimmed);
    return isNaN(date.getTime()) ? null : date;
}

/**
 * sanitizeDescription
 *  - Allows only a limited set of HTML tags (paragraphs, line breaks, bold, italics, lists, headings)
 *  - Strips all other tags and attributes
 *
 * @param {string} html
 * @returns {string} sanitized HTML string
 */
function sanitizeDescription(html) {
    if (typeof html !== 'string') {
        return '';
    }
    return sanitizeHtml(html, {
        allowedTags: [
            'p',
            'br',
            'strong',
            'em',
            'ul',
            'ol',
            'li',
            'h1',
            'h2',
            'h3',
            'h4',
            'blockquote'
        ],
        allowedAttributes: {} // No attributes on any tag
    });
}

/**
 * sanitizeTripPayload
 *  - Applies field‐by‐field sanitization for Trip creation/update endpoints
 *  - Returns a new object containing only the sanitized fields
 *
 * @param {object} payload
 * @returns {{ code:string, name:string, length:number|null, start:Date|null, resort:string, perPerson:number|null, image:string, description:string }}
 */
function sanitizeTripPayload(payload) {
    if (typeof payload !== 'object' || payload === null) {
        return {};
    }

    return {
        code: sanitizeString(payload.code),
        name: sanitizeString(payload.name),
        length: sanitizeNumber(payload.length),
        start: sanitizeDate(payload.start),
        resort: sanitizeString(payload.resort),
        perPerson: sanitizeNumber(payload.perPerson),
        image: sanitizeString(payload.image),
        description: sanitizeDescription(payload.description || '')
    };
}

/**
 * sanitizeQueryParam
 *  - Ensures a query‐string value is a finite positive integer.
 *  - If the incoming value is missing or invalid, returns `defaultValue`.
 *
 * @param {string|number|undefined} rawValue
 * @param {number} defaultValue
 * @returns {number}
 */
function sanitizeQueryParam(rawValue, defaultValue = 1) {
    // If already a number, ensure positive integer
    if (typeof rawValue === 'number') {
        return Number.isFinite(rawValue) && rawValue > 0 ? Math.floor(rawValue) : defaultValue;
    }

    // If it's a string, trim and validate as integer ≥ 1
    if (typeof rawValue === 'string') {
        const trimmed = validator.trim(rawValue);
        if (validator.isInt(trimmed, { min: 1 })) {
            return parseInt(trimmed, 10);
        }
    }

    // Fallback
    return defaultValue;
}

module.exports = {
    sanitizeString,
    sanitizeEmail,
    sanitizeNumber,
    sanitizeDate,
    sanitizeDescription,
    sanitizeTripPayload,
    sanitizeQueryParam
};