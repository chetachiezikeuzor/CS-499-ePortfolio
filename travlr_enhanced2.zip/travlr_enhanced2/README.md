# Travlr Getaways

Welcome to the Travlr Getaways project repository! This application is designed to streamline the travel booking experience for both customers and administrators. Built using the MEAN stack—MongoDB, Express.js, Angular, and Node.js—it offers a robust platform for managing travel packages and bookings.

![Travel_Page_Routing.png](images/travlr_ui.png)

## Table of Contents

- [Overview](#overview)
- [Architecture](#architecture)
- [Functionality](#functionality)
- [Testing](#testing)
- [Reflection](#reflection)
- [Getting Started](#getting-started)
- [Author](#author)

## [Overview](#overview)

Travlr Getaways is a comprehensive travel booking web application that was created for browsing and booking travel packages. Administrators have access to an exclusive single-page application (SPA) to manage these travel packages and adjust pricing structures.

## [Architecture](#architecture)

### Frontend Development Approaches

In this project, two primary frontend development approaches were utilized:

1. **Express with HTML and JavaScript**: This method was employed for the customer-facing side of the application. Using Express.js, server-rendered HTML templates were generated, providing a straightforward and SEO-friendly interface. JavaScript was incorporated to enhance interactivity, allowing dynamic content updates without requiring full-page reloads.

2. **Single-Page Application (SPA) with Angular**: The administrative interface was developed as an SPA using Angular. This approach enables dynamic content updates and a more responsive user experience. Administrators can manage travel packages and user data efficiently without the need for frequent server requests.


### Backend with NoSQL MongoDB Database

The application leverages MongoDB, a NoSQL database, for the backend. MongoDB's flexibility in handling unstructured data and its scalability make it a great choice for applications requiring rapid development and iteration. Its schema-less nature allows for easy modifications and expansions of data models as the application evolves.

## [Functionality](#functionality)

### JSON and JavaScript Integration

JSON (JavaScript Object Notation) serves as a lightweight data interchange format, facilitating seamless communication between the frontend and backend. While JavaScript is a programming language used to manipulate data and handle application logic, JSON provides a standardized format to structure that data. In this application, JSON is used to transmit data between the client-side Angular application and the server-side Express.js API, ensuring consistency and efficiency in data handling.

### Code Refactoring and Reusable UI Components

Throughout the development process, code refactoring was done to enhance functionality and efficiency. One significant improvement was the creation of reusable UI components in Angular. By modularizing components like forms and data tables, the application achieved a more maintainable codebase and a consistent user interface.

## [Testing](#testing)

### API Testing and Security Considerations

The application employs various HTTP methods—GET, POST, PUT, DELETE—to manage data through RESTful API endpoints. Testing these endpoints ensures that data retrieval and manipulation function as intended. With the integration of security measures like JSON Web Tokens (JWT) for authentication, additional testing was conducted to verify that only authorized users can access or modify data. This comprehensive testing approach ensures both functionality and security across the application.

#### Testing the add trip function on the frontend
<!-- ![](images/add_trip_on_ui.png) -->
<img src="images/add_trip_on_ui.png" alt="Add trip form" width="300">

<!-- ![](images/trip_added_on_ui.png) -->
<img src="images/trip_added_on_ui.png" alt="Trip added to UI" width="300">

#### Testing the edit trip function on the frontend
<!-- ![](images/edit_trip_on_ui.png) -->
<img src="images/edit_trip_on_ui.png" alt="Edit trip form" width="300">

<!-- ![](images/trip_edited_on_ui.png) -->
<img src="images/trip_edited_on_ui.png" alt="Trip edited in UI" width="300">


## [Reflection](#reflection)

This project has been instrumental in advancing my full stack development skills. By working with the MEAN stack, I've gained practical experience in building scalable and efficient web applications. The challenges I've faced and overcome during the development of this project have greatly enhanced my problem-solving abilities and prepared me for future projects in the tech industry.

## [Getting Started](#getting-started)

To run this application locally, follow these steps:

1. **Clone the repository**:
   `git clone https://github.com/chetachiezikeuzor/travlr.git`

2. **Navigate to the project directory**:
   `cd travlr`
3. **Create the .env file**
   `touch .env`
    - **Add the required variable**
      `JWT_SECRET=your_secret_key_here`
4. **Install server dependencies**:
   `npm install`
5. **Start the Express server**:
   `npm start`
7. **Navigate to the Angular admin interface directory**:
   `cd app_admin`
    - **Start the admin interface**:
      `ng serve`


Ensure that MongoDB is installed and running on your machine before starting the server.

## [Author](#author)

👤 **Chetachi Ezikeuzor**  
📌 Software Engineer | Full Stack Developer  
🔗 GitHub: [github.com/chetachiezikeuzor](https://github.com/chetachiezikeuzor)  
📧 Email: chetachiezikeuzor@gmail.com
