import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TripCardComponent } from '../trip-card/trip-card.component';
import { Trip } from '../models/trips';
import { TripDataService } from '../services/trip-data.service';
import { Router } from '@angular/router';
import { AuthenticationService } from '../services/authentication';

@Component({
  selector: 'app-trip-listing',
  imports: [CommonModule, TripCardComponent],
  templateUrl: './trip-listing.component.html',
  styleUrls: ['./trip-listing.component.css'],
  standalone: true,
  providers: [TripDataService]
})
export class TripListingComponent implements OnInit {
  trips!: Trip[];
  message: string = '';

  constructor(
    private tripDataService: TripDataService,
    private router: Router,
    private authenticationService: AuthenticationService
  ) {}

  private getTrips(): void {
    this.tripDataService.getTrips().subscribe({
      next: (value: any) => {
        // Since the backend now returns { success, data: { trips: Trip[] , … } },
        // we need to pull out the actual array:
        if (value && value.success && value.data && Array.isArray(value.data.trips)) {
          this.trips = value.data.trips;
          if (this.trips.length > 0) {
            this.message = `There are ${this.trips.length} trips available.`;
          } else {
            this.message = 'There were no trips retrieved from the database';
          }
        } else {
          // In case the response shape is unexpected:
          this.trips = [];
          this.message = 'No trips found';
        }
      },
      error: (error: any) => {
        this.message = 'Error retrieving trips: ' + error;
      }
    });
  }

  ngOnInit(): void {
    this.getTrips();
  }

  public isLoggedIn(): boolean {
    return this.authenticationService.isLoggedIn();
  }

  /**
   * Navigates to the add-trip form.
   */
  public addTrip(): void {
    this.router.navigate(['add-trip']);
  }
}
