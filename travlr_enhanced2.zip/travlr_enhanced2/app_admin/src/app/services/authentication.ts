import { Inject, Injectable } from '@angular/core';
import { BROWSER_STORAGE } from '../storage';
import { User } from '../models/user';
import { AuthResponse } from '../models/authresponse';
import { TripDataService } from '../services/trip-data.service';

/**
 * Service for managing user authentication, registration, and token storage.
 * Provides methods to login, register, logout, check authentication status,
 * and retrieve the current user.
 */
@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
  constructor(
    @Inject(BROWSER_STORAGE) private storage: Storage,
    private tripDataService: TripDataService
  ) {}

  /**
   * Retrieves the JWT token from browser storage.
   * @returns The JWT token string, or null if not found.
   */
  public getToken(): string | null {
    return this.storage.getItem('travlr-token');
  }

  /**
   * Saves a JWT token to browser storage.
   * @param token The JWT token string to save.
   */
  public saveToken(token: string): void {
    this.storage.setItem('travlr-token', token);
  }

  /**
   * Attempts to log in a user with provided credentials.
   * Saves the received JWT token on success.
   * @param user User credentials (email, password, etc.)
   * @returns Promise that resolves when login is complete.
   */
  public login(user: User): Promise<any> {
    return this.tripDataService.login(user)
      .then((authResp: AuthResponse) =>
        this.saveToken(authResp.token));
  }

  /**
   * Registers a new user and saves the received JWT token.
   * @param user New user registration info.
   * @returns Promise that resolves when registration is complete.
   */
  public register(user: User): Promise<any> {
    return this.tripDataService.register(user)
      .then((authResp: AuthResponse) =>
        this.saveToken(authResp.token));
  }

  /**
   * Logs out the current user by removing their JWT token from storage.
   */
  public logout(): void {
    this.storage.removeItem('travlr-token');
  }

  /**
   * Checks if the user is currently logged in and their JWT token is valid.
   * @returns True if user is logged in and token is not expired, false otherwise.
   */
  public isLoggedIn(): boolean {
    const token: string | null = this.getToken();
    if (token) {
      const payload = JSON.parse(atob(token.split('.')[1]));
      return payload.exp > (Date.now() / 1000);
    } else {
      return false;
    }
  }

  /**
   * Retrieves the current user's information from the JWT token.
   * @returns User object with email and name.
   */
  public getCurrentUser(): User {
    const token = this.getToken()!;
    const { email, name } = JSON.parse(atob(token.split('.')[1]));
    return { email, name } as User;
  }
}
