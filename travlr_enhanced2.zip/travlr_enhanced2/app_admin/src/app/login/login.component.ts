import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {AuthenticationService} from '../services/authentication';
import {FormsModule} from '@angular/forms';
import {CommonModule} from '@angular/common';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  imports: [FormsModule, CommonModule],
  styleUrls: ['./login.component.css']
})

/**
 * Component for handling user login.
 * Provides a login form and submits user credentials to the authentication service.
 */
export class LoginComponent implements OnInit {
  public formError: string = '';
  public credentials = {
    name: '',          // <-- Added property so credentials match User
    email: '',
    password: ''
  };

  constructor(
    private router: Router,
    private authenticationService: AuthenticationService
  ) {
  }

  ngOnInit() {
  }

  /**
   * Handles form submission for login.
   * @param evt The form submission event
   */
  public onLoginSubmit(evt: Event): void {
    evt.preventDefault();
    this.formError = '';
    if (!this.credentials.email || !this.credentials.password) {
      this.formError = 'All fields are required, please try again';
    } else {
      this.doLogin();
    }
  }

  private doLogin(): void {
    this.authenticationService.login(this.credentials)
      .then(() => {
        this.router.navigateByUrl('/home');
      })
      .catch((message) => this.formError = message);
  }
}
