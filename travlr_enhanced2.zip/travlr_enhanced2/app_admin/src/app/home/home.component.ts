import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthenticationService } from '../services/authentication';
import { TripListingComponent } from '../trip-listing/trip-listing.component';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, TripListingComponent],
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})

/**
 * Home page component. Displays trip listings and manages authentication checks.
 */
export class HomeComponent implements OnInit {
  constructor(private authService: AuthenticationService) {}

  ngOnInit(): void {}

  /**
   * Check if user is currently logged in.
   * @returns boolean
   */
  public isLoggedIn(): boolean {
    return this.authService.isLoggedIn();
  }
}
