import {Component, OnInit} from '@angular/core';
import {RouterModule} from '@angular/router'; // <-- Import RouterModule
import {CommonModule} from '@angular/common';
import {AuthenticationService} from '../services/authentication';

@Component({
  selector: 'app-navbar',
  // Include RouterModule so that routerLink directives work
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})

/**
 * Navbar component for navigation and authentication actions.
 * Provides login/logout links and displays based on user status.
 */
export class NavbarComponent implements OnInit {
  constructor(private authenticationService: AuthenticationService) {
  }

  ngOnInit(): void {
  }

  public isLoggedIn(): boolean {
    return this.authenticationService.isLoggedIn();
  }

  /**
   * Logs out the current user.
   */
  // Make sure this method is public so that it can be called from the template.
  public onLogout(): void {
    this.authenticationService.logout();
  }
}
