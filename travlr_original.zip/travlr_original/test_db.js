const mongoose = require('mongoose');
const Trip = require('./app_api/models/travlr'); // Import Trip schema

const host = process.env.DB_HOST || '127.0.0.1';
const dbURI = `mongodb://${host}/travlr`;

// Connect to MongoDB
mongoose.connect(dbURI);

mongoose.connection.once('open', async () => {
    console.log(`✓ Connected to MongoDB at ${dbURI}`);

    try {
        // Fetch all trips from the database
        const trips = await Trip.find({});

        // Check if data exists
        if (!trips || trips.length === 0) {
            console.log("✖ No trips found in the database.");
            await mongoose.connection.close();
            process.exit(1); // Exit with error
        }

        // Check if data is in the correct JSON format
        console.log("✓ Trips data retrieved successfully:");
        console.log(JSON.stringify(trips, null, 2));

    } catch (error) {
        console.error("✖ Error fetching trips:", error);
        process.exit(1);
    } finally {
        await mongoose.connection.close();
        console.log("↺ Database connection closed.");
    }
});