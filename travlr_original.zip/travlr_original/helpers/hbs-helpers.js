const registerHelpers = (handlebars) =>{
    handlebars.registerHelper('isActive', function (linkPath, className, options){
        const currentPath = options.data.root.currentPath; // Get access to the current path
        const activeClass = className || 'selected'; // Defaults to selected class if there is no other calss anme
        return currentPath === linkPath ? activeClass : '';
    })
};

module.exports = registerHelpers;