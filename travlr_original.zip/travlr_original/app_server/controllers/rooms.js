var fs = require('fs');
var quarters = JSON.parse(fs.readFileSync('./data/quarters.json', 'utf8'))

/* GET rooms view */
const rooms = (req, res) => {
    res.render('rooms', { title: 'Travlr Getaways', quarters, currentPath: '/rooms'});
}

module.exports = {
    rooms
};