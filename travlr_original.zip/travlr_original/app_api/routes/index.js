const express = require('express'); // Express app
const router = express.Router(); // Router logic
const jwt = require('express-jwt');

const auth = jwt.expressjwt({
    secret: process.env.JWT_SECRET,
    algorithms: ['HS256'], // Required for security
    requestProperty: 'payload' // Attach payload to `req`
})

// This is where we import the controllers we will route
const tripsController = require('../controllers/trips');
const authController = require('../controllers/authentication');

// Define route for out trips endpoint
router
    .route('/trips')
    .get(tripsController.tripsList) // GET method routes tripsList
    .post(auth, tripsController.tripsAddTrip); // POST Method adds trip

// GET method routes tripsFindByCode - requires parameter
router
    .route('/trips/:tripCode')
    .get(tripsController.tripsFindByCode)
    .put(auth, tripsController.tripsUpdateTrip);

router
    .route('/login')
    .post(authController.login);

router
    .route('/register')
    .post(authController.register);


// console.log("API routes loaded");


module.exports = router;