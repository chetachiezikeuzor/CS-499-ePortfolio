const mongoose = require('mongoose');
const Trip = require('../models/travlr'); // Use this directly
const User = require('../models/user');


// GET: /trips - lists all the trips
// Response muse include HTML status code
// and JSON message to the request client
const tripsList = async (req, res) => {
    try {
        const trips = await Trip
            .find({}) // No filter, return all records
            .exec();

        if (!trips.length) {
            // Database returned nothing
            return res.status(404).json({message: "No trips found"});
        }

        // Return trips list
        res.status(200).json(trips);
    } catch (err) {
        res.status(500).json({error: err.message});
    }
};

// GET: /trips/:tripCode - lists a single trip
// Response muse include HTML status code
// and JSON message to the request client
const tripsFindByCode = async (req, res) => {
    try {
        const trips = await Trip
            .findOne({'code': req.params.tripCode}) // Return single record
            .exec();

        if (!trips) {
            // Database returned nothing
            return res.status(404).json({message: "Trip not found"});
        }

        // Return trips list
        res.status(200).json(trips);
    } catch (err) {
        res.status(500).json({error: err.message});
    }
};

// POST: /trips - Adds a new Trip
// Regardless of outcome, response must include HTML status code
// and JSON message to the requesting client
const tripsAddTrip = async (req, res) => {
    try {
        const user = await getUser(req);
        if (!user) {
            return res.status(403).json({error: "Unauthorized: User not found"});
        }

        const newTrip = new Trip({
            code: req.body.code,
            name: req.body.name,
            length: req.body.length,
            start: req.body.start,
            resort: req.body.resort,
            perPerson: req.body.perPerson,
            image: req.body.image,
            description: req.body.description
        });

        const savedTrip = await newTrip.save();
        res.status(201).json(savedTrip);
    } catch (err) {
        console.error("Error adding trip:", err);
        res.status(400).json({error: "Error adding trip", details: err.message});
    }
};

// PUT: /trips/:tripCode - Updates an existing Trip
// Regardless of outcome, response must include HTML status code
// and JSON message to the requesting client
const tripsUpdateTrip = async (req, res) => {
    console.time("DB query")
    try {
        const user = await getUser(req);
        if (!user) {
            return res.status(403).json({error: "Unauthorized: User not found"});
        }

        console.log(req.params);
        console.log(req.body);

        const updatedTrip = await Trip.findOneAndUpdate(
            {'code': req.params.tripCode},  // Search by tripCode
            {
                code: req.body.code,
                name: req.body.name,
                length: req.body.length,
                start: req.body.start,
                resort: req.body.resort,
                perPerson: req.body.perPerson,
                image: req.body.image,
                description: req.body.description
            },
            {new: true, runValidators: true} // Return updated doc & validate changes
        ).exec();

        if (!updatedTrip) {
            return res.status(404).json({error: "Trip not found"});
        }

        res.status(200).json(updatedTrip);
    } catch (err) {
        console.error("Error updating trip:", err);
        res.status(500).json({error: "Internal Server Error"});
    }
    console.timeEnd("DB query")
};


// get authenticated user
const getUser = async (req) => {
    if (!req.payload || !req.payload.email) {
        return null;
    }

    try {
        const user = await User.findOne({ email: req.payload.email }).exec();
        return user ? user.name : null;
    } catch (err) {
        console.error("Error retrieving user:", err);
        return null;
    }
};

module.exports = {
    tripsList,
    tripsFindByCode,
    tripsAddTrip,
    tripsUpdateTrip
}

