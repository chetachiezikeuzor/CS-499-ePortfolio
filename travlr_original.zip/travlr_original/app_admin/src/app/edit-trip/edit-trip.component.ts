import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from "@angular/forms";
import { TripDataService } from '../services/trip-data.service';
import { Trip } from '../models/trips';

@Component({
  selector: 'app-edit-trip',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './edit-trip.component.html',
  styleUrl: './edit-trip.component.css'
})
export class EditTripComponent implements OnInit {
  public editForm!: FormGroup;
  trip!: Trip;
  submitted = false;
  message: string = '';

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private tripDataService: TripDataService
  ) {}

  ngOnInit(): void {
    let tripCode = localStorage.getItem("tripCode");
    if (!tripCode) {
      alert("Something wrong, couldn’t find where I stashed tripCode!");
      this.router.navigate(['']);
      return;
    }

    console.log('EditTripComponent::ngOnInit');
    console.log('tripCode:', tripCode);

    // Fetch trip data from the API
    this.tripDataService.getTrip(tripCode)
      .subscribe({
        next: (value: any) => {
          if (!value) {
            this.message = 'No Trip Retrieved!';
            console.log(this.message);
            return;
          }

          this.trip = value; // Store fetched trip data
          console.log('Trip Data:', this.trip);

          // Initialize form **AFTER** data is retrieved
          this.editForm = this.formBuilder.group({
            _id: [this.trip._id || ''], // Ensure _id is included
            code: [this.trip.code, Validators.required],
            name: [this.trip.name, Validators.required],
            length: [this.trip.length, Validators.required],
            start: [this.trip.start, Validators.required],
            resort: [this.trip.resort, Validators.required],
            perPerson: [this.trip.perPerson, Validators.required],
            image: [this.trip.image, Validators.required],
            description: [this.trip.description, Validators.required]
          });

          this.message = `Trip: ${tripCode} retrieved`;
          console.log(this.message);
        },
        error: (error: any) => {
          console.log('Error:', error);
        }
      });
  }

  public onSubmit() {
    this.submitted = true;
    if (this.editForm.valid) {
      this.tripDataService.updateTrip(this.editForm.value)
        .subscribe({
          next: (value: any) => {
            console.log('Updated Trip:', value);
            this.router.navigate(['']);
          },
          error: (error: any) => {
            console.log('Error:', error);
          }
        });
    }
  }

  get f() { return this.editForm.controls; }
}
