const fs = require('fs');
const quarters = JSON.parse(fs.readFileSync('./data/quarters.json', 'utf8'));

/**
 * Renders the rooms view, showing available quarters.
 * @param {import('express').Request} req Express request object
 * @param {import('express').Response} res Express response object
 */
const rooms = (req, res) => {
    res.render('rooms', { title: 'Travlr Getaways', quarters, currentPath: '/rooms'});
};

module.exports = {
    rooms
};
