/**
 * Uses validator.js and sanitize-html to:
 *  - Trim and escape untrusted strings
 *  - Normalize emails
 *  - Convert/validate numbers and dates
 *  - Whitelist basic HTML in descriptions
 *  - Validate MongoDB ObjectIDs for database operations
 */

const validator    = require('validator');
const sanitizeHtml = require('sanitize-html');

/**
 * Trims and escapes a string to prevent XSS.
 * @param {any} input
 * @returns {string} sanitized string (or empty string if invalid)
 */
function sanitizeString(input) {
    if (typeof input !== 'string') {
        return '';
    }
    const trimmed = validator.trim(input);
    return validator.escape(trimmed);
}

/**
 * Sanitize and normalize an email address.
 * @param {any} email
 * @returns {string} normalized email or empty string if invalid
 */
function sanitizeEmail(email) {
    if (typeof email !== 'string') {
        return '';
    }
    const trimmed = validator.trim(email);
    const normalized = validator.normalizeEmail(trimmed);
    return validator.isEmail(normalized) ? normalized : '';
}

/**
 * Attempts to convert input to a finite number; returns null if invalid.
 * @param {string|number} input
 * @returns {number|null}
 */
function sanitizeNumber(input) {
    if (typeof input === 'number') {
        return Number.isFinite(input) ? input : null;
    }
    if (typeof input !== 'string') {
        return null;
    }
    const trimmed = validator.trim(input);
    if (!validator.isNumeric(trimmed, { no_symbols: true })) {
        return null;
    }
    const num = Number(trimmed);
    return Number.isFinite(num) ? num : null;
}

/**
 * Parses ISO8601 date strings to Date objects; returns null if invalid.
 * @param {string|Date} input
 * @returns {Date|null}
 */
function sanitizeDate(input) {
    if (input instanceof Date) {
        return isNaN(input.getTime()) ? null : input;
    }
    if (typeof input !== 'string') {
        return null;
    }
    const trimmed = validator.trim(input);
    if (!validator.isISO8601(trimmed)) {
        return null;
    }
    const date = new Date(trimmed);
    return isNaN(date.getTime()) ? null : date;
}

/**
 * Sanitizes HTML, allowing only a basic set of tags to prevent XSS.
 * @param {string} html
 * @returns {string}
 */
function sanitizeDescription(html) {
    if (typeof html !== 'string') {
        return '';
    }
    return sanitizeHtml(html, {
        allowedTags: [
            'p', 'br', 'strong', 'em', 'ul', 'ol', 'li',
            'h1', 'h2', 'h3', 'h4', 'blockquote'
        ],
        allowedAttributes: {
            // no attributes allowed
        }
    });
}

/**
 * Validates a MongoDB ObjectId string, returns null if invalid.
 * @param {string} id
 * @returns {string|null}
 */
function sanitizeObjectId(id) {
    if (typeof id !== 'string') {
        return null;
    }
    const trimmed = validator.trim(id);
    return validator.isMongoId(trimmed) ? trimmed : null;
}

/**
 * Applies field-by-field sanitization for Trip create/update payloads.
 * @param {object} payload
 * @returns {{ code:string, name:string, length:number|null, start:Date|null, resort:string, perPerson:number|null, image:string, description:string }}
 */
function sanitizeTripPayload(payload) {
    if (typeof payload !== 'object' || payload === null) {
        return {};
    }
    return {
        code: sanitizeString(payload.code),
        name: sanitizeString(payload.name),
        length: sanitizeNumber(payload.length),
        start: sanitizeDate(payload.start),
        resort: sanitizeString(payload.resort),
        perPerson: sanitizeNumber(payload.perPerson),
        image: sanitizeString(payload.image),
        description: sanitizeDescription(payload.description || '')
    };
}

/**
 * Applies field-by-field sanitization for User create/update payloads.
 * @param {object} payload
 * @returns {{ email:string, name:string, password:string }}
 */
function sanitizeUserPayload(payload) {
    if (typeof payload !== 'object' || payload === null) {
        return {};
    }
    return {
        email: sanitizeEmail(payload.email),
        name: sanitizeString(payload.name),
        password: sanitizeString(payload.password)
    };
}

/**
 * Ensures a query value is a finite positive integer; returns default if invalid.
 * @param {string|number|undefined} rawValue
 * @param {number} defaultValue
 * @returns {number}
 */
function sanitizeQueryParam(rawValue, defaultValue = 1) {
    const num = Number(rawValue);
    return Number.isInteger(num) && num > 0 ? num : defaultValue;
}

module.exports = {
    sanitizeString,
    sanitizeEmail,
    sanitizeNumber,
    sanitizeDate,
    sanitizeDescription,
    sanitizeObjectId,
    sanitizeTripPayload,
    sanitizeUserPayload,
    sanitizeQueryParam
};
