/**
 * Express router for Trip CRUD and cost-calculation operations.
 * Public: list, get by id, calculate cost.
 * Protected: create, update, delete (admin only).
 */

const express = require('express');
const { body, param, query } = require('express-validator');
const Trip = require('../models/travlr');
const logger = require('../logger');
const { STATUS, ERRORS } = require('../constants');
const { handleServerError } = require('../utils/errorHandlers');
const {
    sanitizeTripPayload,
    sanitizeQueryParam,
    sanitizeObjectId,
    sanitizeString
} = require('../utils/sanitizersHelpers');
const validateRequest = require('../middleware/validateRequest');
const { requireAuth, requireAdmin } = require('../middleware/auth');

const router = express.Router();

/**
 * @route   GET /api/trips
 * @desc    List trips with pagination and optional sorting
 * @access  Public
 */
router.get(
    '/',
    [
        query('page').optional().toInt(),
        query('limit').optional().toInt(),
        query('sortBy').optional().trim()
    ],
    validateRequest,
    async (req, res) => {
        try {
            const page = sanitizeQueryParam(req.query.page, 1);
            const limit = sanitizeQueryParam(req.query.limit, 10);
            let sortBy = 'name';
            if (req.query.sortBy) {
                const candidate = sanitizeString(req.query.sortBy);
                // Only allow whitelisted fields to sort by
                if (Trip.schema.path(candidate)) sortBy = candidate;
            }

            const total = await Trip.countDocuments();
            const trips = await Trip.find()
                .sort({ [sortBy]: 1 })
                .skip((page - 1) * limit)
                .limit(limit)
                .lean();

            return res.status(STATUS.OK).json({
                success: true,
                data: { page, totalPages: Math.ceil(total / limit), total, trips }
            });
        } catch (err) {
            return handleServerError(res, err, 'GET /api/trips');
        }
    }
);

/**
 * @route   GET /api/trips/:id
 * @desc    Retrieve a trip by its ID
 * @access  Public
 */
router.get(
    '/:id',
    [
        param('id').customSanitizer(sanitizeObjectId).notEmpty().withMessage('Invalid ID')
    ],
    validateRequest,
    async (req, res) => {
        try {
            const trip = await Trip.findById(req.params.id).lean();
            if (!trip) {
                return res.status(STATUS.NOT_FOUND).json({ success: false, message: ERRORS.TRIP_NOT_FOUND });
            }
            return res.status(STATUS.OK).json({ success: true, data: trip });
        } catch (err) {
            return handleServerError(res, err, 'GET /api/trips/:id');
        }
    }
);

/**
 * @route   GET /api/trips/:id/cost/:groupSize
 * @desc    Calculate total cost for a group
 * @access  Public
 */
router.get(
    '/:id/cost/:groupSize',
    [
        param('id').customSanitizer(sanitizeObjectId).notEmpty().withMessage('Invalid ID'),
        param('groupSize').toInt().isInt({ min: 1 }).withMessage('Group size must be a positive integer')
    ],
    validateRequest,
    async (req, res) => {
        try {
            const trip = await Trip.findById(req.params.id).lean();
            if (!trip) {
                return res.status(STATUS.NOT_FOUND).json({ success: false, message: ERRORS.TRIP_NOT_FOUND });
            }
            const groupSize = req.params.groupSize;
            const totalCost = trip.perPerson * groupSize;
            return res.status(STATUS.OK).json({
                success: true,
                data: { tripCode: trip.code, groupSize, costPerPerson: trip.perPerson, totalCost }
            });
        } catch (err) {
            return handleServerError(res, err, 'GET /api/trips/:id/cost/:groupSize');
        }
    }
);

/**
 * @route   POST /api/trips
 * @desc    Create a new trip
 * @access  Admin
 */
router.post(
    '/',
    requireAuth,
    requireAdmin,
    [
        body('code').notEmpty().withMessage('Code is required'),
        body('name').notEmpty().withMessage('Name is required'),
        body('length').isInt({ min: 1 }).withMessage('Length must be at least 1'),
        body('start').isISO8601().withMessage('Start must be a valid date'),
        body('resort').notEmpty().withMessage('Resort is required'),
        body('perPerson').isFloat({ min: 0 }).withMessage('Per person cost must be non-negative'),
        body('image').isURL().withMessage('Image must be a valid URL'),
        body('description').notEmpty().withMessage('Description is required')
    ],
    validateRequest,
    async (req, res) => {
        try {
            const payload = sanitizeTripPayload(req.body);
            if (await Trip.findOne({ code: payload.code })) {
                return res.status(STATUS.CONFLICT).json({ success: false, message: ERRORS.DUPLICATE_CODE });
            }
            const trip = await Trip.create(payload);
            return res.status(STATUS.CREATED).json({ success: true, data: trip });
        } catch (err) {
            return handleServerError(res, err, 'POST /api/trips');
        }
    }
);

/**
 * @route   PUT /api/trips/:id
 * @desc    Update a trip by ID
 * @access  Admin
 */
router.put(
    '/:id',
    requireAuth,
    requireAdmin,
    [
        param('id').customSanitizer(sanitizeObjectId).notEmpty().withMessage('Invalid ID')
    ],
    validateRequest,
    async (req, res) => {
        try {
            const payload = sanitizeTripPayload(req.body);
            const updated = await Trip.findByIdAndUpdate(req.params.id, payload, { new: true, runValidators: true }).lean();
            if (!updated) {
                return res.status(STATUS.NOT_FOUND).json({ success: false, message: ERRORS.TRIP_NOT_FOUND });
            }
            return res.status(STATUS.OK).json({ success: true, data: updated });
        } catch (err) {
            return handleServerError(res, err, 'PUT /api/trips/:id');
        }
    }
);

/**
 * @route   DELETE /api/trips/:id
 * @desc    Delete a trip by ID
 * @access  Admin
 */
router.delete(
    '/:id',
    requireAuth,
    requireAdmin,
    [
        param('id').customSanitizer(sanitizeObjectId).notEmpty().withMessage('Invalid ID')
    ],
    validateRequest,
    async (req, res) => {
        try {
            const deleted = await Trip.findByIdAndDelete(req.params.id).lean();
            if (!deleted) {
                return res.status(STATUS.NOT_FOUND).json({ success: false, message: ERRORS.TRIP_NOT_FOUND });
            }
            return res.status(STATUS.OK).json({ success: true, message: 'Trip deleted' });
        } catch (err) {
            return handleServerError(res, err, 'DELETE /api/trips/:id');
        }
    }
);

module.exports = router;
