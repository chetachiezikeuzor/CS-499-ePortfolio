/**
 * Express router for user authentication (register/login) for Travlr Getaways.
 * Provides secure registration and login using model hooks and JWT.
 */

const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
const validateRequest = require('../middleware/validateRequest');
const { sanitizeRegisterFields } = require('../middleware/sanitizers');
const { sanitizeEmail, sanitizeString } = require('../utils/sanitizersHelpers');
const { handleServerError } = require('../utils/errorHandlers');
const User = require('../models/user');
const logger = require('../logger');
const { STATUS, ERRORS } = require('../constants');

/**
 * @route   POST /api/auth/register
 * @desc    Register a new user
 * @access  Public
 */
router.post(
    '/register',
    sanitizeRegisterFields,
    [
        body('name').trim().notEmpty().withMessage('Name is required'),
        body('email').isEmail().withMessage('Must be a valid email'),
        body('password').isLength({ min: 8 }).withMessage('Password must be at least 8 characters')
    ],
    validateRequest,
    async (req, res) => {
        try {
            const name = sanitizeString(req.body.name);
            const email = sanitizeEmail(req.body.email);
            const password = sanitizeString(req.body.password);

            const existing = await User.findOne({ email });
            if (existing) {
                logger.warn(`Registration attempt for existing user: ${email}`);
                return res.status(STATUS.BAD_REQUEST).json({ success: false, message: ERRORS.USER_EXISTS });
            }

            const user = new User({ name, email, password, role: 'user' });
            await user.save();
            const token = user.generateJwt();
            logger.info(`New user registered: ${email}`);
            return res.status(STATUS.CREATED).json({ success: true, data: { token } });
        } catch (err) {
            logger.error('Registration error:', err);
            return handleServerError(res, err, 'REGISTER');
        }
    }
);

/**
 * @route   POST /api/auth/login
 * @desc    Authenticate user & return JWT
 * @access  Public
 */
router.post(
    '/login',
    [
        body('email').isEmail().withMessage('Must be a valid email'),
        body('password').exists().withMessage('Password is required')
    ],
    validateRequest,
    async (req, res) => {
        try {
            const email = sanitizeEmail(req.body.email);
            const password = sanitizeString(req.body.password);

            const user = await User.findOne({ email });
            if (!user) {
                logger.warn(`Login failed: user not found (${email})`);
                return res.status(STATUS.BAD_REQUEST).json({ success: false, message: ERRORS.INVALID_CREDENTIALS });
            }

            const valid = await user.comparePassword(password);
            if (!valid) {
                logger.warn(`Login failed: invalid password for ${email}`);
                return res.status(STATUS.BAD_REQUEST).json({ success: false, message: ERRORS.INVALID_CREDENTIALS });
            }

            const token = user.generateJwt();
            logger.info(`User logged in: ${email}`);
            return res.status(STATUS.OK).json({ success: true, data: { token } });
        } catch (err) {
            logger.error('Login error:', err);
            return handleServerError(res, err, 'LOGIN');
        }
    }
);

module.exports = router;