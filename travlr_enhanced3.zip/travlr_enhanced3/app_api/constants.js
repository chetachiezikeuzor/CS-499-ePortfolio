/**
 * Centralized HTTP status codes and error messages for Travlr API.
 */

const STATUS = {
    OK:           200,
    CREATED:      201,
    BAD_REQUEST:  400,
    UNAUTHORIZED: 401,
    FORBIDDEN:    403,
    NOT_FOUND:    404,
    CONFLICT:     409,
    SERVER_ERROR: 500
};

const ERRORS = {
    UNAUTHORIZED:        'Unauthorized access',
    FORBIDDEN:           'Admin access required',
    FIELDS_REQUIRED:     'All fields are required',
    TRIP_NOT_FOUND:      'Trip not found',
    DUPLICATE_CODE:      'Trip code already exists',
    VALIDATION:          'Validation failed',
    SERVER:              'An unexpected server error occurred',
    USER_EXISTS:         'User already exists',
    INVALID_CREDENTIALS: 'Invalid credentials',
    INVALID_PASSWORD:    'Invalid password',
    INVALID_EMAIL:       'Invalid email'
};

module.exports = { STATUS, ERRORS };