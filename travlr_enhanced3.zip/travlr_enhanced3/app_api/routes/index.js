/**
 * API routes for Travlr Getaways backend.
 * Includes trip CRUD endpoints and authentication.
 * All routes are mounted under /api in the main app.
 */
const express = require('express');
const router = express.Router();
const { STATUS } = require('../constants');

// Controllers
const authRouter = require('../controllers/authentication');
const tripsRouter = require('../controllers/trips');

/**
 * @route   GET /api
 * @desc    API root - health check and welcome message
 * @access  Public
 */
router.get('/', (req, res) =>
    res.status(STATUS.OK).json({ success: true, message: 'Welcome to Travlr API!' })
);

// Authentication routes
router.use('/auth', authRouter);

// Trip routes
router.use('/trips', tripsRouter);

module.exports = router;
