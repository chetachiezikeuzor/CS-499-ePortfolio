// ───────────────────────────────────────────────────
// Mongoose User model for Travlr Getaways.
// The `password` field contains a bcrypt hash. Plaintext passwords are never stored.
// Provides instance methods to compare passwords and generate signed JWTs.
// ───────────────────────────────────────────────────

const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');
const validator = require('validator');
const bcrypt = require('bcryptjs');
const uniqueValidator = require('mongoose-unique-validator');

const userSchema = new mongoose.Schema(
    {
        email: {
            type: String,
            required: [true, 'Email is required.'],
            unique: true,
            index: true,
            lowercase: true,
            trim: true,
            validate: {
                validator: (v) => validator.isEmail(v),
                message: (props) => `${props.value} is not a valid email address.`,
            },
        },
        name: {
            type: String,
            required: [true, 'Name is required.'],
            trim: true,
            minlength: [2, 'Name must be at least 2 characters.'],
            maxlength: [50, 'Name must be at most 50 characters.'],
        },
        password: {
            type: String,
            required: [true, 'Password is required.'],
            minlength: [8, 'Password must be at least 8 characters long.'],
        },
        role: {
            type: String,
            enum: ['user', 'admin'],
            default: 'user',
        },
    },
    {
        timestamps: true,
        toJSON: {
            virtuals: true,
            transform(doc, ret) {
                ret.id = ret._id;
                delete ret._id;
                delete ret.__v;
                delete ret.password;
            },
        },
    }
);

// Plugin for better unique validation errors
userSchema.plugin(uniqueValidator, { message: '{PATH} must be unique.' });

/**
 * Hash the password before saving, if modified.
 */
userSchema.pre('save', async function (next) {
    if (!this.isModified('password')) return next();
    try {
        const salt = await bcrypt.genSalt(12);
        this.password = await bcrypt.hash(this.password, salt);
        next();
    } catch (err) {
        next(err);
    }
});

/**
 * Compare a plaintext password to the stored hash.
 * @param {string} candidate
 * @returns {Promise<boolean>}
 */
userSchema.methods.comparePassword = function (candidate) {
    return bcrypt.compare(candidate, this.password);
};

/**
 * Generate a signed JWT for this user.
 * Payload includes user id, email, name, and role.
 * Expires in 7 days by default.
 * @returns {string} JWT token
 */
userSchema.methods.generateJwt = function () {
    if (!process.env.JWT_SECRET) {
        throw new Error('JWT_SECRET must be set in environment');
    }
    return jwt.sign(
        {
            sub:   this._id,
            email: this.email,
            name:  this.name,
            role:  this.role,
        },
        process.env.JWT_SECRET,
        { expiresIn: '7d' }
    );
};

// Static helper to find a user by email
userSchema.statics.findByEmail = function (email) {
    return this.findOne({ email: email.toLowerCase().trim() }).exec();
};

module.exports = mongoose.model('User', userSchema);
