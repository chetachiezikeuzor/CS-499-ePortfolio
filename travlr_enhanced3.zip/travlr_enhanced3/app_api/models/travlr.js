/**
 * Mongoose schema and model for trips in Travlr Getaways.
 * Each trip has a unique code, name, length, start date, resort,
 * perPerson cost, image, and description. This model enforces strict
 * validation and a unique constraint on trip codes.
 */

const mongoose = require('mongoose');
const uniqueValidator = require('mongoose-unique-validator');
const { isURL } = require('validator');

// Schema definition for a trip
const tripSchema = new mongoose.Schema({
    code: {
        type: String,
        required: [true, 'Trip code is required.'],
        unique: true,
        index: true,
        trim: true,
        uppercase: true
    },
    name: {
        type: String,
        required: [true, 'Trip name is required.'],
        index: true,
        trim: true
    },
    length: {
        type: Number,
        required: [true, 'Trip length is required.'],
        min: [1, 'Trip length must be at least 1 day.']
    },
    start: {
        type: Date,
        required: [true, 'Start date is required.']
    },
    resort: {
        type: String,
        required: [true, 'Resort is required.'],
        trim: true
    },
    perPerson: {
        type: Number,
        required: [true, 'Per person cost is required.'],
        min: [0, 'Per person cost must be non-negative.']
    },
    image: {
        type: String,
        required: [true, 'Image URL is required.'],
        validate: {
            validator: (v) => isURL(v, { protocols: ['http', 'https'], require_protocol: true }),
            message: (props) => `${props.value} is not a valid URL.`
        }
    },
    description: {
        type: String,
        required: [true, 'Trip description is required.'],
        trim: true
    }
}, {
    timestamps: true // Adds createdAt and updatedAt fields automatically
});

// Plugin to provide meaningful error messages for unique constraints
tripSchema.plugin(uniqueValidator, { message: '{PATH} must be unique.' });

/**
 * Instance method to calculate total cost for a given group size.
 * @param {number} groupSize
 * @returns {number} total cost
 */
tripSchema.methods.calculateCost = function(groupSize) {
    return this.perPerson * groupSize;
};

/**
 * Static method to find a trip by its code (case-insensitive).
 * @param {string} code
 * @returns {Promise<Trip>}
 */
tripSchema.statics.findByCode = function(code) {
    return this.findOne({ code: code.toUpperCase().trim() }).exec();
};

// Export the Trip model, using the collection "trips"
module.exports = mongoose.model('Trip', tripSchema, 'trips');
