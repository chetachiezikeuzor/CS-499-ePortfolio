/**
 * Proxy module for the shared Mongoose connection.
 * Re-exports the instance from config/database.js to ensure single setup.
 */
module.exports = require('../config/database');
