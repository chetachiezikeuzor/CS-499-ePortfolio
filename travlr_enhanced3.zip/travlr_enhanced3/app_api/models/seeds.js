/**
 * Seeds the database with trip data from data/trips.json.
 * Converts length and perPerson fields to Numbers as per schema requirements.
 * Uses Winston for structured logging.
 */
const mongoose = require('./db');
const Trip     = require('./travlr');
const fs       = require('fs/promises');
const path     = require('path');
const logger   = require('../logger');

(async function seedDB() {
    try {
        // Read seed file
        const filePath = path.join(__dirname, '../../data/trips.json');
        const raw      = await fs.readFile(filePath, 'utf8');
        let trips      = JSON.parse(raw);

        // Normalize data types
        trips = trips.map(trip => ({
            code:      String(trip.code).trim().toUpperCase(),
            name:      String(trip.name).trim(),
            start:     new Date(trip.start),
            resort:    String(trip.resort).trim(),
            length:    Number(trip.length),
            perPerson: Number(trip.perPerson),
            image:     String(trip.image).trim(),
            description: String(trip.description).trim(),
        }));

        // Clear existing collection
        const delResult = await Trip.deleteMany({});
        logger.info(`Cleared existing trips: ${delResult.deletedCount} removed`);

        // Insert new documents (unordered to continue on error)
        const inserted = await Trip.insertMany(trips, { ordered: false });
        logger.info(`Inserted ${inserted.length} trip records`);
    } catch (err) {
        logger.error('Error during seeding:', err.message || err);
        process.exit(1);
    } finally {
        // Close mongoose connection and exit
        mongoose.connection.close(() => {
            logger.info('Mongoose connection closed after seeding');
            process.exit(0);
        });
    }
})();