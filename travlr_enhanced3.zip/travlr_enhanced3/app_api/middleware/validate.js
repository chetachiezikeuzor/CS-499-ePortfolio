/**
 * Express validation middleware for user registration and trip creation.
 * Uses express-validator to ensure required fields and correct data formats.
 */

const { body, validationResult } = require('express-validator');
const { STATUS, ERRORS } = require('../constants');

/**
 * Validation chain for user registration input.
 */
const validateRegister = [
    body('name')
        .trim()
        .escape()
        .notEmpty()
        .withMessage(ERRORS.FIELDS_REQUIRED)
        .isString()
        .withMessage('Name must be a string'),
    body('email')
        .trim()
        .notEmpty()
        .withMessage(ERRORS.FIELDS_REQUIRED)
        .isEmail()
        .withMessage(ERRORS.INVALID_EMAIL)
        .normalizeEmail(),
    body('password')
        .notEmpty()
        .withMessage(ERRORS.FIELDS_REQUIRED)
        .isLength({ min: 8 })
        .withMessage('Password must be at least 8 characters')
        .matches(/[a-z]/)
        .withMessage('Password must contain a lowercase letter')
        .matches(/[A-Z]/)
        .withMessage('Password must contain an uppercase letter')
        .matches(/\d/)
        .withMessage('Password must contain a number'),
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(STATUS.BAD_REQUEST).json({
                success: false,
                errors: errors.array(),
                message: ERRORS.VALIDATION
            });
        }
        next();
    }
];

/**
 * Validation chain for trip creation/update input.
 */
const validateTrip = [
    body('code')
        .trim()
        .escape()
        .notEmpty()
        .withMessage(ERRORS.FIELDS_REQUIRED)
        .isString()
        .withMessage('Trip code must be a string'),
    body('name')
        .trim()
        .escape()
        .notEmpty()
        .withMessage(ERRORS.FIELDS_REQUIRED)
        .isString()
        .withMessage('Trip name must be a string'),
    body('length')
        .notEmpty()
        .withMessage(ERRORS.FIELDS_REQUIRED)
        .isInt({ min: 1 })
        .withMessage('Length must be a positive integer'),
    body('start')
        .notEmpty()
        .withMessage(ERRORS.FIELDS_REQUIRED)
        .isISO8601()
        .toDate()
        .withMessage('Start must be a valid ISO8601 date'),
    body('resort')
        .trim()
        .escape()
        .notEmpty()
        .withMessage(ERRORS.FIELDS_REQUIRED)
        .isString()
        .withMessage('Resort must be a string'),
    body('perPerson')
        .notEmpty()
        .withMessage(ERRORS.FIELDS_REQUIRED)
        .isFloat({ min: 0 })
        .withMessage('Per person must be a positive number'),
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(STATUS.BAD_REQUEST).json({
                success: false,
                errors: errors.array(),
                message: ERRORS.VALIDATION
            });
        }
        next();
    }
];

module.exports = { validateRegister, validateTrip };
