/**
 * Authentication middleware for protected and admin routes.
 * Validates JWT tokens and checks for admin privileges.
 */
const jwt     = require('jsonwebtoken');
const { STATUS, ERRORS } = require('../constants');
const logger  = require('../logger');

/**
 * requireAuth - Ensures the request has a valid JWT.
 * Attaches decoded token (payload) to req.user.
 */
function requireAuth(req, res, next) {
    const header = req.headers.authorization;
    const token  = header && header.startsWith('Bearer ') && header.split(' ')[1];

    if (!token) {
        logger.warn('Unauthorized: Missing token');
        return res.status(STATUS.UNAUTHORIZED).json({ success: false, message: ERRORS.UNAUTHORIZED });
    }

    try {
        if (!process.env.JWT_SECRET) throw new Error('JWT_SECRET not set in environment');
        req.user = jwt.verify(token, process.env.JWT_SECRET);
        next();
    } catch (err) {
        logger.warn(`Unauthorized: ${err.message}`);
        return res.status(STATUS.UNAUTHORIZED).json({ success: false, message: ERRORS.UNAUTHORIZED });
    }
}

/**
 * requireAdmin - Ensures the authenticated user has 'admin' role.
 */
function requireAdmin(req, res, next) {
    if (!req.user || req.user.role !== 'admin') {
        logger.warn('Forbidden: Admin access required');
        return res.status(STATUS.FORBIDDEN).json({ success: false, message: ERRORS.FORBIDDEN });
    }
    next();
}

module.exports = { requireAuth, requireAdmin };
