/**
 * Middleware to sanitize incoming request data.
 *  - For registration: sanitize name/email
 *  - For trip endpoints: sanitize entire trip payload
 *  - For query parameters: sanitize page, limit, sortBy
 */

const logger = require('../logger');
const {
    sanitizeString,
    sanitizeEmail,
    sanitizeTripPayload,
    sanitizeQueryParam
} = require('../utils/sanitizersHelpers');

/**
 * sanitizeRegisterFields
 *  - Trim, escape, and normalize name & email
 *  - If an error occurs during sanitization, it is logged but not thrown.
 *
 * @param {import('express').Request} req
 * @param {import('express').Response} res
 * @param {import('express').NextFunction} next
 */
function sanitizeRegisterFields(req, res, next) {
    try {
        if (req.body.name) {
            // Trim and escape any HTML from name
            req.body.name = sanitizeString(req.body.name);
        }
        if (req.body.email) {
            // Trim and normalize email
            req.body.email = sanitizeEmail(req.body.email);
        }
    } catch (err) {
        // Log the error; validation will catch invalid values later
        logger.error('Sanitization error in sanitizeRegisterFields:', {
            message: err.message,
            stack: err.stack
        });
    } finally {
        next();
    }
}

/**
 * sanitizeTripFields
 *  - Applies sanitizeTripPayload to req.body
 *  - Ensures only valid keys & types remain; everything else is stripped out.
 *  - If an error occurs, it is logged; req.body is left unchanged or blank.
 *
 * @param {import('express').Request} req
 * @param {import('express').Response} res
 * @param {import('express').NextFunction} next
 */
function sanitizeTripFields(req, res, next) {
    try {
        // Overwrite req.body with a fully sanitized payload object
        req.body = sanitizeTripPayload(req.body);
    } catch (err) {
        logger.error('Sanitization error in sanitizeTripFields:', {
            message: err.message,
            stack: err.stack
        });
        // If sanitization fails, leave req.body as-is (validation middleware will catch missing/invalid fields)
    } finally {
        next();
    }
}

/**
 * sanitizeQueryParams
 *  - Ensures page and limit become positive integers ≥ 1 (fallback to default)
 *  - Ensures sortBy is safely escaped as a string
 *
 * @param {import('express').Request} req
 * @param {import('express').Response} res
 * @param {import('express').NextFunction} next
 */
function sanitizeQueryParams(req, res, next) {
    try {
        if (req.query.page !== undefined) {
            req.query.page = sanitizeQueryParam(req.query.page, 1);
        }
        if (req.query.limit !== undefined) {
            req.query.limit = sanitizeQueryParam(req.query.limit, 10);
        }
        if (req.query.sortBy !== undefined) {
            req.query.sortBy = sanitizeString(req.query.sortBy);
        }
    } catch (err) {
        logger.error('Sanitization error in sanitizeQueryParams:', {
            message: err.message,
            stack: err.stack
        });
        // Even if sanitization fails, let the request continue; validation or default logic applies.
    } finally {
        next();
    }
}

module.exports = {
    sanitizeRegisterFields,
    sanitizeTripFields,
    sanitizeQueryParams
};