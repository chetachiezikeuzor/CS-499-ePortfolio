// ───────────────────────────────────────────────────
// Mongoose connection setup for Travlr Getaways.
// • Reads DB_HOST, DB_PORT, DB_NAME, DB_URI, DB_POOL_SIZE from env
// • Configures connection pooling and timeouts
// • Logs connection events via Winston
// • Handles graceful shutdown on SIGINT, SIGTERM, SIGUSR2
// ───────────────────────────────────────────────────

const mongoose = require('mongoose');
const logger = require('../logger'); // Winston logger instance

// Environment variables with sensible defaults
const host     = process.env.DB_HOST       || '127.0.0.1';
const port     = process.env.DB_PORT       || '27017';
const dbName   = process.env.DB_NAME       || 'travlr';
const poolSize = parseInt(process.env.DB_POOL_SIZE, 10) || 10;

// Construct the MongoDB URI if not explicitly provided
const uri = process.env.DB_URI || `mongodb://${host}:${port}/${dbName}`;

// Connection options
const opts = {
    useNewUrlParser:    true,
    useUnifiedTopology: true,
    maxPoolSize:        poolSize,
    serverSelectionTimeoutMS: 5000,  // fail fast if cannot connect
};

// Establish connection
mongoose.connect(uri, opts)
    .then(() => logger.info(`✔︎ MongoDB connected to ${uri}`))
    .catch(err => {
        logger.error(`✖︎ MongoDB connection error:`, err);
        process.exit(1);
    });

// Log Mongoose connection events
mongoose.connection.on('connected',    () => logger.info(`Mongoose connected to ${uri}`));
mongoose.connection.on('error',        err => logger.error('Mongoose connection error:', err));
mongoose.connection.on('disconnected', () => logger.info('Mongoose disconnected'));

/**
 * Gracefully closes the Mongoose connection.
 *
 * This function is used to terminate the database connection safely
 * during application shutdown or restart signals. Ensures that all
 * resources are released properly and logs the disconnection reason.
 *
 * @param {string} msg - A message indicating the context of shutdown (e.g. 'app termination').
 * @param {function} [callback] - Optional callback function to be invoked after disconnection.
 *
 * @returns {void}
 */
const gracefulShutdown = (msg, callback) => {
    mongoose.connection.close(() => {
        logger.info(`Mongoose disconnected through ${msg}`);
        if (callback) callback();
    });
};

// Capture termination / restart signals
process.once('SIGUSR2', () => gracefulShutdown('nodemon restart', () => process.kill(process.pid, 'SIGUSR2')));
process.on('SIGINT',  () => gracefulShutdown('app termination',  () => process.exit(0)));
process.on('SIGTERM', () => gracefulShutdown('app shutdown', () => process.exit(0)));

module.exports = mongoose;