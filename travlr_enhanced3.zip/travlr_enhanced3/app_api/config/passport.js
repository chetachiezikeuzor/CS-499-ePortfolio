/**
 * Configures Passport.js JWT authentication strategy for Travlr Getaways API.
 * Validates users based on JWT tokens sent in the Authorization header.
 *
 * - Requires process.env.JWT_SECRET to be set.
 * - Adds req.user to requests where JWT is valid.
 * - Returns 401 Unauthorized if token is missing/invalid.
 */

const passport = require('passport');
const { Strategy: JwtStrategy, ExtractJwt } = require('passport-jwt');
const User = require('../models/user');
const { ERRORS } = require('../constants');

/**
 * JWT Strategy options.
 * - jwtFromRequest: how to extract the token (from Authorization header, Bearer scheme)
 * - secretOrKey: the signing secret for JWT (must be set in environment)
 */
const opts = {
    jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
    secretOrKey: process.env.JWT_SECRET
};

/**
 * JWT authentication strategy for API requests.
 *
 * @param {Object} payload - The decoded JWT payload.
 * @param {Function} done - Passport callback.
 */
passport.use(
    new JwtStrategy(opts, async (payload, done) => {
        try {
            // By convention, use "sub" (subject) or "_id" as user ID in token payload
            const userId = payload.sub || payload._id || payload.id;
            const user = await User.findById(userId).lean();
            if (!user) {
                // User not found: fail authentication
                return done(null, false, { message: ERRORS.UNAUTHORIZED });
            }
            // Authenticated: attach user
            return done(null, user);
        } catch (err) {
            // Any error: fail authentication
            return done(err, false);
        }
    })
);

module.exports = passport;

