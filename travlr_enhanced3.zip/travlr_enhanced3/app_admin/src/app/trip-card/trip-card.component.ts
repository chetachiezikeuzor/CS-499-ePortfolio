import {Component, Input, OnInit} from '@angular/core';
import {CommonModule} from "@angular/common";
import {Trip} from "../models/trips";
import {Router} from "@angular/router";
import {AuthenticationService} from "../services/authentication";

@Component({
  selector: 'app-trip-card',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './trip-card.component.html',
  styleUrl: './trip-card.component.css'
})

/**
 * Card component to display an individual trip.
 * Handles edit navigation and authentication checks.
 */
export class TripCardComponent implements OnInit {
  @Input('trip') trip: any;

  constructor(private router: Router, private authenticationService: AuthenticationService) {
  }

  ngOnInit() {
  }

  public isLoggedIn(): boolean {
    return this.authenticationService.isLoggedIn()
  }


  /**
   * Navigates to the edit page for the selected trip.
   * @param trip The trip to edit
   */
  public editTrip(trip: Trip) {
    localStorage.removeItem('tripCode');
    localStorage.setItem('tripCode', trip.code);
    this.router.navigate(['edit-trip'])
  }
}
