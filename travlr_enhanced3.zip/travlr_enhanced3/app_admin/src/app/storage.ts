import {InjectionToken} from '@angular/core';

/**
 * Injection token for browser localStorage access.
 * Used throughout the app for authentication and data storage.
 */
export const BROWSER_STORAGE = new
InjectionToken<Storage>('Browser Storage', {
  providedIn: 'root',
  factory: () => localStorage
});
