import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TripCardComponent } from '../trip-card/trip-card.component';
import { Trip } from '../models/trips';
import { TripDataService } from '../services/trip-data.service';
import { Router } from '@angular/router';
import { AuthenticationService } from '../services/authentication';

@Component({
  selector: 'app-trip-listing',
  standalone: true,
  imports: [CommonModule, TripCardComponent],
  templateUrl: './trip-listing.component.html',
  styleUrls: ['./trip-listing.component.css'],
  providers: [TripDataService]
})
export class TripListingComponent implements OnInit {
  trips: Trip[] = [];
  message: string = '';

  constructor(
    private tripDataService: TripDataService,
    private router: Router,
    private authenticationService: AuthenticationService
  ) {}

  private getTrips(): void {
    this.tripDataService.getTrips().subscribe({
      next: (value: any) => {
        // value is { success: boolean, data: { page, totalPages, totalTrips, trips: Trip[] } }
        if (value && value.success && value.data && Array.isArray(value.data.trips)) {
          this.trips = value.data.trips;
          if (this.trips.length > 0) {
            this.message = `There are ${this.trips.length} trips available.`;
          } else {
            this.message = 'There were no trips retrieved from the database';
          }
        } else {
          // If for some reason data.trips is missing or not an array, we treat as “no trips”
          this.trips = [];
          this.message = 'No trips found';
        }
      },
      error: (error: any) => {
        this.message = 'Error retrieving trips: ' + (error.message || error);
      }
    });
  }

  ngOnInit(): void {
    this.getTrips();
  }

  public isLoggedIn(): boolean {
    return this.authenticationService.isLoggedIn();
  }

  public addTrip(): void {
    this.router.navigate(['add-trip']);
  }
}
