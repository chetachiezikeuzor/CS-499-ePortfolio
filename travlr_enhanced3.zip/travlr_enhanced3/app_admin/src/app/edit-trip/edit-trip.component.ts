import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from "@angular/forms";
import { TripDataService } from '../services/trip-data.service';
import { Trip } from '../models/trips';

@Component({
  selector: 'app-edit-trip',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './edit-trip.component.html',
  styleUrl: './edit-trip.component.css'
})

/**
 * Component for editing an existing trip.
 * Loads trip data from the API, populates a reactive form, and updates on submit.
 */
export class EditTripComponent implements OnInit {
  public editForm!: FormGroup;
  trip!: Trip;
  submitted = false;
  message: string = '';

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private tripDataService: TripDataService
  ) {}

  ngOnInit(): void {
    let tripCode = localStorage.getItem("tripCode");
    if (!tripCode) {
      alert("Something wrong, couldn’t find where I stashed tripCode!");
      this.router.navigate(['']);
      return;
    }

    // Fetch trip data from the API
    this.tripDataService.getTrip(tripCode)
      .subscribe({
        next: (value: any) => {
          if (!value) {
            this.message = 'No Trip Retrieved!';
            return;
          }

          this.trip = value; // Store fetched trip data

          // Initialize form **AFTER** data is retrieved
          this.editForm = this.formBuilder.group({
            _id: [this.trip._id || ''], // Ensure _id is included
            code: [this.trip.code, Validators.required],
            name: [this.trip.name, Validators.required],
            length: [this.trip.length, Validators.required],
            start: [this.trip.start, Validators.required],
            resort: [this.trip.resort, Validators.required],
            perPerson: [this.trip.perPerson, Validators.required],
            image: [this.trip.image, Validators.required],
            description: [this.trip.description, Validators.required]
          });

          this.message = `Trip: ${tripCode} retrieved`;
        },
        error: (error: any) => {
          this.message = 'Error retrieving trip data.';
        }
      });
  }

  /**
   * Handle form submission to update the selected trip.
   */
  public onSubmit() {
    this.submitted = true;
    if (this.editForm.valid) {
      this.tripDataService.updateTrip(this.editForm.value)
        .subscribe({
          next: (value: any) => {
            this.router.navigate(['']);
          },
          error: (error: any) => {
            this.message = 'Error updating trip.';
          }
        });
    }
  }

  get f() { return this.editForm.controls; }
}
