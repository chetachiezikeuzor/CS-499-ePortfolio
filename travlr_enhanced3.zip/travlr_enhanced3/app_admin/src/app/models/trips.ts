/**
 * Interface describing the structure of a Trip object.
 */
export interface Trip {
  /** MongoDB unique identifier for the trip */
  _id: string;
  /** Unique trip code */
  code: string;
  /** Trip name */
  name: string;
  /** Length of the trip in days */
  length: number;
  /** Start date of the trip */
  start: Date;
  /** Resort or destination name */
  resort: string;
  /** Price per person for the trip */
  perPerson: number;
  /** Image URL or filename */
  image: string;
  /** Trip description */
  description: string;
}
