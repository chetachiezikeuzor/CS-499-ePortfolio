/**
 * Class representing a user for authentication and registration.
 */
export class User {
  /** User's email address */
  email: string = '';
  /** User's name (required for registration, optional for login) */
  name?: string;
  /** User's role ('user' or 'admin') */
  role?: 'user' | 'admin'; // Optional if not required at creation, but you can make it required if needed
}
