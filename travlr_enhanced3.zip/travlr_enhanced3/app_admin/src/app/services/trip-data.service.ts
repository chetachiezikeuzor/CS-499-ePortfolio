// src/app/services/trip-data.service.ts

import { Inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { lastValueFrom, Observable, throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';

import { Trip } from '../models/trips';
import { User } from '../models/user';
import { AuthResponse } from '../models/authresponse';
import { BROWSER_STORAGE } from '../storage';

/**
 * Shape of the “get all trips” response from backend:
 * {
 *   success: boolean,
 *   data: {
 *     page: number,
 *     totalPages: number,
 *     totalTrips: number,
 *     trips: Trip[]
 *   }
 * }
 */
interface TripsResponse {
  success: boolean;
  data: {
    page: number;
    totalPages: number;
    totalTrips: number;
    trips: Trip[];
  };
}

/**
 * Shape of the “get or mutate single trip” response:
 * {
 *   success: boolean,
 *   data: Trip
 * }
 */
interface SingleTripResponse {
  success: boolean;
  data: Trip;
}

/**
 * Shape of the authentication responses from backend:
 * {
 *   success: boolean,
 *   data: { token: string }       // e.g. { token: "…" }
 * }
 */
interface AuthResponseWrapper {
  success: boolean;
  data: {
    token: string;
  };
}

/**
 * Service for handling all HTTP requests related to trips and authentication.
 * Provides:
 *  - getTrips(): Observable<Trip[]>
 *  - getTrip(code: string): Observable<Trip>
 *  - addTrip(trip: Trip): Observable<Trip>
 *  - updateTrip(trip: Trip): Observable<Trip>
 *  - login(user: User): Promise<AuthResponse>
 *  - register(user: User): Promise<AuthResponse>
 */
@Injectable({
  providedIn: 'root'
})
export class TripDataService {
  private readonly apiBaseUrl = 'http://localhost:3000/api/';
  private readonly tripsUrl = `${this.apiBaseUrl}trips/`;

  constructor(
    private http: HttpClient,
    @Inject(BROWSER_STORAGE) private storage: Storage
  ) {}

  // ─── Trips Endpoints ─────────────────────────────────────────────────────

  /**
   * Fetches all trips from the backend API.
   * The backend returns { success: true, data: { page, totalPages, totalTrips, trips: Trip[] } }.
   * We “unwrap” to return Observable<Trip[]> only.
   */
  public getTrips(
    page: number = 1,
    limit: number = 10,
    sortBy: string = 'name'
  ): Observable<Trip[]> {
    const url = `${this.tripsUrl}?page=${page}&limit=${limit}&sortBy=${sortBy}`;
    return this.http.get<TripsResponse>(url).pipe(
      map((resp: TripsResponse) => {
        // We expect resp.data.trips to be an array
        if (resp.success && Array.isArray(resp.data.trips)) {
          return resp.data.trips;
        }
        // If something’s off, throw to be caught below
        throw new Error('Unexpected trips response format');
      }),
      catchError((err) => {
        console.error('Error in getTrips():', err);
        return throwError(() => err);
      })
    );
  }

  /**
   * Fetches a specific trip by its code from the backend API.
   * The backend returns { success: true, data: Trip }.
   * We unwrap to return Observable<Trip> directly.
   */
  public getTrip(tripCode: string): Observable<Trip> {
    const url = `${this.tripsUrl}${encodeURIComponent(tripCode)}`;
    return this.http.get<SingleTripResponse>(url).pipe(
      map((resp: SingleTripResponse) => {
        if (resp.success && resp.data) {
          return resp.data;
        }
        throw new Error(`Trip not found in getTrip(${tripCode})`);
      }),
      catchError((err) => {
        console.error(`Error in getTrip(${tripCode}):`, err);
        return throwError(() => err);
      })
    );
  }

  /**
   * Adds a new trip to the backend API.
   * The backend responds { success: true, data: Trip }.
   * We unwrap to return Observable<Trip>.
   */
  public addTrip(trip: Trip): Observable<Trip> {
    return this.http.post<SingleTripResponse>(this.tripsUrl, trip).pipe(
      map((resp: SingleTripResponse) => {
        if (resp.success && resp.data) {
          return resp.data;
        }
        throw new Error('Unexpected response from addTrip()');
      }),
      catchError((err) => {
        console.error('Error in addTrip():', err);
        return throwError(() => err);
      })
    );
  }

  /**
   * Updates an existing trip in the backend API.
   * We assume `trip.code` is the unique identifier.
   * The server responds with { success: true, data: Trip } after updating.
   * We unwrap to return Observable<Trip>.
   */
  public updateTrip(trip: Trip): Observable<Trip> {
    const url = `${this.tripsUrl}${encodeURIComponent(trip.code)}`;
    return this.http.put<SingleTripResponse>(url, trip).pipe(
      map((resp: SingleTripResponse) => {
        if (resp.success && resp.data) {
          return resp.data;
        }
        throw new Error(`Unexpected response from updateTrip(${trip.code})`);
      }),
      catchError((err) => {
        console.error(`Error in updateTrip(${trip.code}):`, err);
        return throwError(() => err);
      })
    );
  }

  /**
   * Deletes a trip by code in the backend API.
   * The server responds { success: true, data: Trip } for the deleted trip.
   * We can unwrap, but sometimes you just want to know it succeeded. Here, we return Observable<void>.
   */
  public deleteTrip(tripCode: string): Observable<void> {
    const url = `${this.tripsUrl}${encodeURIComponent(tripCode)}`;
    return this.http.delete<SingleTripResponse>(url).pipe(
      map((resp: SingleTripResponse) => {
        if (resp.success) {
          // Ignore the payload; caller just needs to know deletion succeeded
          return;
        }
        throw new Error(`Unexpected response from deleteTrip(${tripCode})`);
      }),
      catchError((err) => {
        console.error(`Error in deleteTrip(${tripCode}):`, err);
        return throwError(() => err);
      })
    );
  }

  // ─── Authentication Endpoints ─────────────────────────────────────────────

  /**
   * Helper method to perform login or register calls.
   * Expects backend path: 'http://localhost:3000/api/login' or '/register'
   * Backend returns { success: true, data: { token: string } }.
   * We unwrap so that caller obtains `AuthResponse` (which we define as { token: string }).
   */
  private async makeAuthApiCall(
    endpoint: 'login' | 'register',
    user: User
  ): Promise<{ token: string }> {
    const url = `${this.apiBaseUrl}${endpoint}`;
    try {
      const respWrapper = await lastValueFrom(
        this.http.post<AuthResponseWrapper>(url, user)
      );
      if (respWrapper.success && respWrapper.data?.token) {
        return { token: respWrapper.data.token };
      }
      throw new Error(`Authentication failed for ${endpoint}`);
    } catch (err) {
      console.error(`Error in ${endpoint}():`, err);
      return Promise.reject(err);
    }
  }

  /**
   * Attempts to log in a user by sending credentials to the API.
   * @param user The user credentials { email, password }.
   * @returns Promise resolving with { token: string } on success.
   */
  public login(user: User): Promise<{ token: string }> {
    return this.makeAuthApiCall('login', user);
  }

  /**
   * Attempts to register a new user by sending { name, email, password } to the API.
   * @param user The user registration info.
   * @returns Promise resolving with { token: string } on success.
   */
  public register(user: User): Promise<{ token: string }> {
    return this.makeAuthApiCall('register', user);
  }

  // ─── Optional: Helpers for storing the token in localStorage ──────────────

  /**
   * Save JWT into local storage.
   */
  public saveToken(token: string): void {
    this.storage.setItem('travlr_token', token);
  }

  /**
   * Retrieve the saved JWT (or null if not present).
   */
  public getToken(): string | null {
    return this.storage.getItem('travlr_token');
  }

  /**
   * Remove JWT from local storage.
   */
  public removeToken(): void {
    this.storage.removeItem('travlr_token');
  }

  /**
   * Check if user is currently “logged in” (token exists and not expired).
   */
  public isLoggedIn(): boolean {
    const token = this.getToken();
    if (!token) {
      return false;
    }
    // Optionally, decode and check expiry here before returning true/false.
    return true;
  }
}
