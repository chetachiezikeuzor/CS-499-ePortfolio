const mongoose = require('mongoose');
const Trip = require('./app_api/models/travlr'); // Import Trip schema
const logger = require('/app_api/logger'); // Use Winston for all logging

const host = process.env.DB_HOST || '127.0.0.1';
const dbURI = `mongodb://${host}/travlr`;

// Connect to MongoDB
mongoose.connect(dbURI);

/**
 * @file Test script to check MongoDB connection and output all trips.
 * Uses Winston logger for output consistency.
 */

mongoose.connection.once('open', async () => {
    logger.info(`✓ Connected to MongoDB at ${dbURI}`);

    try {
        // Fetch all trips from the database
        const trips = await Trip.find({});

        // Check if data exists
        if (!trips || trips.length === 0) {
            logger.warn("✖ No trips found in the database.");
            await mongoose.connection.close();
            process.exit(1); // Exit with error
        }

        // Check if data is in the correct JSON format
        logger.info("✓ Trips data retrieved successfully:");
        logger.info(JSON.stringify(trips, null, 2));

    } catch (error) {
        logger.error("✖ Error fetching trips:", error);
        process.exit(1);
    } finally {
        await mongoose.connection.close();
        logger.info("↺ Database connection closed.");
    }
});
