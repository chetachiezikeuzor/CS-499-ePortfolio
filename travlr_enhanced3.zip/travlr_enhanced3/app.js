// ───────────────────────────────────────────────────
// Main Express application file for Travlr Getaways.
// Entry point for the Node.js server.
//
// Sets up:
//  • Environment variables
//  • Database connection
//  • Logging & parsing middleware
//  • CORS (for Angular or other frontends)
//  • Passport initialization
//  • API routes (JSON)
//  • View routes (Handlebars, if still used)
//  • 404 + error handling (JSON vs. HTML)
//
// Adjust paths as needed if our folder structure differs.
// ───────────────────────────────────────────────────

require('dotenv').config();

const createError = require('http-errors');
const express= require('express');
const path = require('path');
const cookieParser = require('cookie-parser');
const morgan = require('morgan');
const cors = require('cors');
const helmet = require('helmet');
const compression  = require('compression');
const rateLimit = require('express-rate-limit');
const passport = require('passport');
const hbs = require('hbs');
const registerHelpers= require('./helpers/hbs-helpers'); // if you still need Handlebars helpers

// ─── Database Connection & Passport Config ─────────
require('./app_api/models/db');        // mongoose.connect(...) inside
require('./app_api/config/passport');  // JWT strategy, etc.

// ─── Create Express App ────────────────────────────
const app = express();

// ─── View Engine Setup (for server‐rendered pages) ─
app.set('views', path.join(__dirname, 'app_server', 'views'));
app.set('view engine', 'hbs');
hbs.registerPartials(path.join(__dirname, 'app_server', 'views', 'partials'));
registerHelpers(hbs);

// ─── Global Middleware ─────────────────────────────
// 0. Security headers
app.use(helmet());

// 1. HTTP request logger (dev vs. combined for prod)
if (process.env.NODE_ENV === 'development') {
  app.use(morgan('dev'));
} else {
  app.use(morgan('combined'));
}

// 2. Body parsers (limit payload to 10kb)
app.use(express.json({ limit: '10kb' }));
app.use(express.urlencoded({ extended: false, limit: '10kb' }));

// 3. Cookie parser (if you need to read cookies)
app.use(cookieParser());

// 4. Passport initialization for protected routes
app.use(passport.initialize());

// 5. Compression (gzip)
app.use(compression());

// 6. Rate limiting on /api routes
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  standardHeaders: true,
  legacyHeaders: false,
});
app.use('/api/', apiLimiter);

// 7. CORS setup (allow Angular at http://localhost:4200)
const corsOptions = {
  origin: 'http://localhost:4200',
  methods: ['GET','POST','PUT','DELETE','OPTIONS'],
  allowedHeaders: ['Content-Type','Authorization','Origin','Accept'],
  credentials: true
};
app.use(cors(corsOptions));
app.options('*', cors(corsOptions)); // preflight

// ─── Static Files (if you serve any client assets on the same server) ───
app.use(express.static(path.join(__dirname, 'public')));

// ─── API ROUTES (JSON) ────────────────────────────────────────────────
// Mount under /api
//   • /api/auth     → authentication.js
//   • /api/trips    → trips.js
//
const authRouter = require('./app_api/controllers/authentication');
const tripsRouter = require('./app_api/controllers/trips');

// Sanitize query‐string params on all /api/trips GET requests (page, limit, sortBy)
const { sanitizeQueryParams } = require('./app_api/middleware/sanitizers');
// Sanitize registration fields on /api/auth/register
const { sanitizeRegisterFields } = require('./app_api/middleware/sanitizers');
// Sanitize trip payload fields on POST/PUT /api/trips
const { sanitizeTripFields } = require('./app_api/middleware/sanitizers');

// 1. Authentication endpoints
app.use(
    '/api/auth',
    sanitizeRegisterFields,    // sanitize name/email on register
    authRouter
);

// 2. Trips endpoints
app.use(
    '/api/trips',
    sanitizeQueryParams,       // for GET /api/trips?page=&limit=&sortBy=
    sanitizeTripFields,        // for POST/PUT payloads
    tripsRouter
);

// ─── VIEW ROUTES (Handlebars) ─────────────────────────────────────────
// If you still serve server‐rendered pages under '/', mount them **after** API routes:
const indexRouter  = require('./app_server/routes/index');
const usersRouter  = require('./app_server/routes/users');
const travelRouter = require('./app_server/routes/travel');
const roomsRouter  = require('./app_server/routes/rooms');

app.use('/',      indexRouter);
app.use('/users', usersRouter);
app.use('/travel',travelRouter);
app.use('/rooms', roomsRouter);

// ─── 404 HANDLING ────────────────────────────────────────────────────
// If no route matched above, check if it's an API path or a view path:
//  • If URL starts with /api, respond with JSON 404
//  • Otherwise, forward to standard 404 page render
//
app.use((req, res, next) => {
  if (req.originalUrl.startsWith('/api/')) {
    return res.status(404).json({ success: false, message: 'API endpoint not found' });
  }
  next(createError(404)); // will be handled by view error handler
});

// ─── ERROR HANDLING ─────────────────────────────────────────────────
// 1. Handle UnauthorizedError thrown by passport (if using express‐jwt, for instance)
app.use((err, req, res, next) => {
  if (err.name === 'UnauthorizedError') {
    return res.status(401).json({ success: false, message: `${err.name}: ${err.message}` });
  }
  next(err);
});

// 2. View‐rendered error handler (for /, /users, /travel, /rooms, etc.)
app.use((err, req, res, next) => {
  // If this request was to /api, skip; let JSON error above (or next) handle it
  if (req.originalUrl.startsWith('/api/')) {
    return res.status(err.status || 500).json({ success: false, message: err.message || 'Server error' });
  }

  // Otherwise assume it’s a view‐route error: render error.hbs
  res.locals.message = err.message;
  res.locals.error   = req.app.get('env') === 'development' ? err : {};
  res.status(err.status || 500);
  res.render('error');
});

// ─── EXPORT EXPRESS APP ───────────────────────────────────────────────
module.exports = app;
