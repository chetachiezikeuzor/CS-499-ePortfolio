/**
 * Trip API routes/controller for Travlr application.
 * Handles CRUD operations with validation, error handling, and logging.
 */

const express = require('express');
const router = express.Router();
const Trip = require('../models/travlr');
const { validateTrip } = require('../middleware/validate');
const { requireAuth, requireAdmin } = require('../middleware/auth');
const { STATUS, ERRORS } = require('../constants');
const logger = require('../logger'); // Use Winston for all logging


/**
 * @route   GET /trips
 * @desc    Get all trips
 * @access  Public
 */
router.get('/', async (req, res) => {
    try {
        const trips = await Trip.find({});
        if (!trips.length) {
            logger.info('No trips found');
            return res.status(STATUS.NOT_FOUND).json({ message: ERRORS.TRIP_NOT_FOUND });
        }
        res.status(STATUS.OK).json(trips);
    } catch (err) {
        logger.error('Fetching trips failed:', err);
        res.status(STATUS.SERVER_ERROR).json({ message: ERRORS.SERVER });
    }
});

/**
 * @route   GET /trips/:tripCode
 * @desc    Get a single trip by code
 * @access  Public
 */
router.get('/:tripCode', async (req, res) => {
    try {
        const trip = await Trip.findOne({ code: req.params.tripCode });
        if (!trip) {
            logger.info(`Trip not found: ${req.params.tripCode}`);
            return res.status(STATUS.NOT_FOUND).json({ message: ERRORS.TRIP_NOT_FOUND });
        }
        res.status(STATUS.OK).json(trip);
    } catch (err) {
        logger.error('Fetch trip by code failed:', err);
        res.status(STATUS.SERVER_ERROR).json({ message: ERRORS.SERVER });
    }
});

/**
 * @route   POST /trips
 * @desc    Create a new trip (admin only)
 * @access  Admin
 */
router.post('/', requireAuth, requireAdmin, validateTrip, async (req, res) => {
    try {
        // Enforce unique code before creating
        const existing = await Trip.findOne({ code: req.body.code });
        if (existing) {
            logger.warn(`Duplicate trip code: ${req.body.code}`);
            return res.status(STATUS.BAD_REQUEST).json({ message: ERRORS.DUPLICATE_CODE });
        }
        const trip = new Trip(req.body);
        await trip.save();
        logger.info(`Trip created: ${trip.code}`);
        res.status(STATUS.OK).json(trip);
    } catch (err) {
        logger.error('Trip creation failed:', err);
        if (err.name === 'ValidationError') {
            return res.status(STATUS.BAD_REQUEST).json({ message: err.message });
        }
        res.status(STATUS.SERVER_ERROR).json({ message: ERRORS.SERVER });
    }
});

/**
 * @route   PUT /trips/:tripCode
 * @desc    Update an existing trip (admin only)
 * @access  Admin
 */
router.put('/:tripCode', requireAuth, requireAdmin, validateTrip, async (req, res) => {
    try {
        const updatedTrip = await Trip.findOneAndUpdate(
            { code: req.params.tripCode },
            req.body,
            { new: true, runValidators: true }
        );
        if (!updatedTrip) {
            logger.info(`Trip not found for update: ${req.params.tripCode}`);
            return res.status(STATUS.NOT_FOUND).json({ message: ERRORS.TRIP_NOT_FOUND });
        }
        logger.info(`Trip updated: ${updatedTrip.code}`);
        res.status(STATUS.OK).json(updatedTrip);
    } catch (err) {
        logger.error('Trip update failed:', err);
        if (err.name === 'ValidationError') {
            return res.status(STATUS.BAD_REQUEST).json({ message: err.message });
        }
        res.status(STATUS.SERVER_ERROR).json({ message: ERRORS.SERVER });
    }
});

/**
 * @route   DELETE /trips/:tripCode
 * @desc    Delete a trip (admin only)
 * @access  Admin
 */
router.delete('/:tripCode', requireAuth, requireAdmin, async (req, res) => {
    try {
        const deletedTrip = await Trip.findOneAndDelete({ code: req.params.tripCode });
        if (!deletedTrip) {
            logger.info(`Trip not found for deletion: ${req.params.tripCode}`);
            return res.status(STATUS.NOT_FOUND).json({ message: ERRORS.TRIP_NOT_FOUND });
        }
        logger.info(`Trip deleted: ${deletedTrip.code}`);
        res.status(STATUS.OK).json({ message: `Trip ${deletedTrip.code} deleted.` });
    } catch (err) {
        logger.error('Trip deletion failed:', err);
        res.status(STATUS.SERVER_ERROR).json({ message: ERRORS.SERVER });
    }
});

module.exports = router;
