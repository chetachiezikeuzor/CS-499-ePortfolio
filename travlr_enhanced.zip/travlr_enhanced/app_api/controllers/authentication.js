/**
 * Express router for user authentication (register/login) for Travlr Getaways.
 * Provides secure registration and login using bcrypt and JWT.
 */
const express = require('express');
const router = express.Router();
const { validateRegister } = require('../middleware/validate');
const User = require('../models/user');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const logger = require('../logger'); // Use Winston for all logging
const { STATUS, ERRORS } = require('../constants');



/**
 * @route   POST /auth/register
 * @desc    Register a new user
 * @access  Public
 */
router.post('/register', validateRegister, async (req, res) => {
    try {
        const { name, email, password } = req.body;
        const existing = await User.findOne({ email });
        if (existing) {
            logger.warn('Attempt to register existing user');
            return res.status(STATUS.BAD_REQUEST).json({ message: ERRORS.USER_EXISTS || 'User already exists' });
        }
        const hashedPassword = await bcrypt.hash(password, 12);
        const user = new User({ name, email, password: hashedPassword, role: 'user' });
        await user.save();
        if (!process.env.JWT_SECRET) throw new Error('JWT_SECRET not set in environment');
        const token = jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET, { expiresIn: '1d' });
        logger.info(`New user registered: ${email}`);
        return res.status(STATUS.OK).json({ token });
    } catch (err) {
        logger.error('Registration error:', err);
        return res.status(STATUS.SERVER_ERROR).json({ message: ERRORS.SERVER || 'Registration failed' });
    }
});

/**
 * @route   POST /auth/login
 * @desc    Authenticate user & return JWT
 * @access  Public
 */
router.post('/login', async (req, res) => {
    const { email, password } = req.body;
    if (!email || !password) {
        return res.status(STATUS.BAD_REQUEST).json({ message: ERRORS.FIELDS_REQUIRED });
    }
    try {
        const user = await User.findOne({ email });
        if (!user) {
            logger.warn('User login failed: user not found');
            return res.status(STATUS.BAD_REQUEST).json({ message: ERRORS.INVALID_CREDENTIALS || 'Invalid credentials' });
        }
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            logger.warn('User login failed: invalid password');
            return res.status(STATUS.BAD_REQUEST).json({ message: ERRORS.INVALID_CREDENTIALS || 'Invalid credentials' });
        }
        if (!process.env.JWT_SECRET) throw new Error('JWT_SECRET not set in environment');
        const token = jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET, { expiresIn: '1d' });
        logger.info(`User logged in: ${email}`);
        return res.status(STATUS.OK).json({ token });
    } catch (err) {
        logger.error('Login error:', err);
        return res.status(STATUS.SERVER_ERROR).json({ message: ERRORS.SERVER || 'Login failed' });
    }
});

module.exports = router;
