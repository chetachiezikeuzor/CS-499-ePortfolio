/**
 * Seeds the database with trip data from data/trips.json.
 * Converts length and perPerson fields to Numbers as per schema requirements.
 * Uses Winston for logging.
 */
const Mongoose = require('./db');
const Trip = require('./travlr');
const fs = require('fs');
const path = require('path');
const logger = require('../logger'); // Use Winston for all logging

// Read and validate seed data from json file
let tripsRaw;
try {
    tripsRaw = fs.readFileSync(path.join(__dirname, '../../data/trips.json'), 'utf8');
} catch (err) {
    logger.error('Error reading trips.json:', err.message);
    process.exit(1);
}

let trips;
try {
    trips = JSON.parse(tripsRaw);

    // Enforce types: length and perPerson must be numbers (schema changed)
    trips = trips.map(trip => ({
        ...trip,
        length: Number(trip.length),
        perPerson: Number(trip.perPerson),
    }));
} catch (err) {
    logger.error('Error parsing trips.json:', err.message);
    process.exit(1);
}

// Enhanced seeding with logging and error handling
const seedDB = async () => {
    try {
        await Trip.deleteMany({});
        logger.info('Cleared existing trips.');

        const inserted = await Trip.insertMany(trips);
        logger.info(`Inserted ${inserted.length} trips.`);
    } catch (err) {
        logger.error('Error seeding trips:', err.message);
    }
};

seedDB().then(async () => {
    await Mongoose.connection.close();
    process.exit(0);
});
