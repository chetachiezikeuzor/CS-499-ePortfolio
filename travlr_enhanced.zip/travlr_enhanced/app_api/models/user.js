/**
 * Mongoose User model for Travlr Getaways.
 * The `password` field contains a bcrypt hash. Plaintext passwords are never stored.
 */

const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');

const userSchema = new mongoose.Schema({
    email: {
        type: String,
        unique: true,
        required: true,
        index: true // For faster lookups
    },
    name: {
        type: String,
        required: true
    },
    password: { // Stores the bcrypt hash
        type: String,
        required: true
    },
    role: {
        type: String,
        enum: ['user', 'admin'],
        default: 'user'
    }
});

/**
 * Generates a signed JWT token for the user.
 */
userSchema.methods.generateJwt = function () {
    const expiry = new Date();
    expiry.setDate(expiry.getDate() + 7);
    return jwt.sign({
        _id: this._id,
        email: this.email,
        name: this.name,
        role: this.role,
        exp: parseInt(expiry.getTime() / 1000, 10),
    }, process.env.JWT_SECRET);
};

const User = mongoose.model('User', userSchema);
module.exports = User;
