/**
 * Initializes MongoDB connection with Mongoose.
 * Sets up graceful shutdown and cross-platform signal handling.
 * Uses Winston for structured logging.
 */
const mongoose = require('mongoose');
const logger = require('../logger'); // Use Winston for all logging
require('dotenv').config();
const host = process.env.DB_HOST || '127.0.0.1';
const dbURI = `mongodb://${host}/travlr`;
const readLine = require('readline');

// Build the connection string and set the connection timeout.
const connect = async () => {
    try {
        await mongoose.connect(dbURI, { useNewUrlParser: true, useUnifiedTopology: true });
        logger.info(`Mongoose connected to ${dbURI}`);
    } catch (err) {
        logger.error('Mongoose connection error:', err);
    }
};

connect();

// Monitor connection events
mongoose.connection.on('connected', () => {
    logger.info(`Mongoose connected to ${dbURI}`);
});
mongoose.connection.on('error', err => {
    logger.error('Mongoose connection error: ', err);
});
mongoose.connection.on('disconnected', () => {
    logger.info('Mongoose disconnected');
});

// Windows specific listener
if (process.platform === 'win32') {
    const r1 = readLine.createInterface({
        input: process.stdin,
        output: process.stdout
    });
    r1.on('SIGINT', () => {
        process.emit("SIGINT");
    });
}

// Configure for Graceful Shutdown
const gracefulShutdown = (msg) => {
    mongoose.connection.close(() => {
        logger.info(`Mongoose disconnected through ${msg}`);
    });
};

// Event Listeners to process graceful shutdowns
// Shutdown invoked by nodemon signal
process.once('SIGUSR2', () => {
    gracefulShutdown('nodemon restart');
    process.kill(process.pid, 'SIGUSR2');
});
// Shutdown invoked by app termination
process.on('SIGINT', () => {
    gracefulShutdown('app termination');
    process.exit(0);
});
// Shutdown invoked by container termination
process.on('SIGTERM', () => {
    gracefulShutdown('app shutdown');
    process.exit(0);
});

// Import Mongoose schema
require('./travlr');
require('./user');

// logger.info('Registered models:', mongoose.modelNames());

module.exports = mongoose;
