/**
 * Express validation middleware for user registration and trip creation.
 * Ensures required fields and correct data formats using express-validator.
 */
const { body, validationResult } = require('express-validator');
const { STATUS, ERRORS } = require('../constants');

/**
 * Validation chain for user registration input.
 */
const validateRegister = [
    body('name')
        .trim()
        .escape()
        .notEmpty().withMessage(ERRORS.FIELDS_REQUIRED)
        .custom(val => typeof val === 'string').withMessage('Name must be a string'),
    body('email')
        .isEmail().withMessage(ERRORS.FIELDS_REQUIRED)
        .normalizeEmail(),
    body('password')
        .isLength({ min: 8 }).withMessage('Password must be at least 8 characters')
        .matches(/[a-z]/).withMessage('Password must contain a lowercase letter')
        .matches(/[A-Z]/).withMessage('Password must contain an uppercase letter')
        .matches(/\d/).withMessage('Password must contain a number'),
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(STATUS.BAD_REQUEST).json({ errors: errors.array(), message: ERRORS.VALIDATION });
        }
        next();
    }
];

/**
 * Validation chain for trip creation/update input.
 */
const validateTrip = [
    body('code')
        .trim()
        .escape()
        .notEmpty().withMessage(ERRORS.FIELDS_REQUIRED)
        .custom(val => typeof val === 'string').withMessage('Trip code must be a string'),
    body('name')
        .trim()
        .escape()
        .notEmpty().withMessage(ERRORS.FIELDS_REQUIRED)
        .custom(val => typeof val === 'string').withMessage('Trip name must be a string'),
    body('length')
        .isInt({ min: 1 }).withMessage('Length must be a positive integer'),
    body('start')
        .isISO8601().toDate().withMessage('Start must be a valid date'),
    body('resort')
        .trim()
        .escape()
        .notEmpty().withMessage(ERRORS.FIELDS_REQUIRED)
        .custom(val => typeof val === 'string').withMessage('Resort must be a string'),
    body('perPerson')
        .isFloat({ min: 0 }).withMessage('Per person must be a positive number'),
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(STATUS.BAD_REQUEST).json({ errors: errors.array(), message: ERRORS.VALIDATION });
        }
        next();
    }
];

module.exports = { validateRegister, validateTrip };
