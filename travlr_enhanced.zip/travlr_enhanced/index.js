console.log('Happy developing ✨')

