const tripsEndpoint = 'http://localhost:3000/api/trips';
const options = {
    method: 'GET',
    headers: {
        'Accept': 'application/json',
    }
};
const logger = require('../../app_api/logger'); // Use Winston for all logging

/**
 * Renders the travel view by fetching trips from the backend API.
 * Displays all trips or an error message if fetch fails.
 * @param {import('express').Request} req Express request object
 * @param {import('express').Response} res Express response object
 * @param {import('express').NextFunction} next Express next middleware
 */
const travel = async function(req, res, next) {
    await fetch(tripsEndpoint, options)
        .then(res => res.json())
        .then(json => {
            let message = null;
            if (!(json instanceof Array)) {
                message = 'API lookup error';
                json = [];
            } else {
                if (!json.length) {
                    message = 'No trips exist in our database!';
                }
            }
            res.render('travel', { title: 'Travlr Getaways', trips: json, currentPath: '/travel', message });
        })
        .catch(err => {
            logger.error('Error fetching trips for travel page:', err);
            res.status(500).send('An error occurred while loading trips.');
        });
};

module.exports = {
    travel
};