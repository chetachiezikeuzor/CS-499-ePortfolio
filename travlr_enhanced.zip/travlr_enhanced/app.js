/**
 * Main Express application file for Travlr Getaways.
 * Sets up view engine, middleware, routing, error handling, CORS, authentication, and static files.
 * Entry point for the Node.js server.
 */

require('dotenv').config();

const cors = require('cors');
const createError = require('http-errors');
const express = require('express');
const path = require('path');
const cookieParser = require('cookie-parser');
const logger = require('morgan');
const hbs = require('hbs');
const registerHelpers = require('./helpers/hbs-helpers');
const passport = require('passport');

// Import routers
const indexRouter = require('./app_server/routes/index');
const usersRouter = require('./app_server/routes/users');
const travelRouter = require('./app_server/routes/travel');
const roomsRouter = require('./app_server/routes/rooms');
const apiRouter = require('./app_api/routes/index');
const handlebars = require('hbs');

// Connect to the database and configure authentication
require('./app_api/models/db');
require('./app_api/config/passport');

const app = express();

// ==== View Engine Setup ====
app.set('views', path.join(__dirname, 'app_server', 'views'));
app.set('view engine', 'hbs');
handlebars.registerPartials(__dirname + '/app_server/views/partials');
registerHelpers(hbs);

// ==== Middleware ====
app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(passport.initialize());

// ==== CORS Setup (for Angular frontend) ====
const corsOptions = {
  origin: 'http://localhost:4200',
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'Origin', 'Accept'],
  credentials: true
};
app.use(cors(corsOptions));
app.options('*', cors(corsOptions)); // Handle preflight requests

// ==== Routing ====
app.use('/api', require('./app_api/routes/index'));
app.use('/', indexRouter);
app.use('/users', usersRouter);
app.use('/travel', travelRouter);
app.use('/rooms', roomsRouter);
app.use('/api', apiRouter);

// ==== Static Files ====
app.use(express.static(path.join(__dirname, 'public')));

// ==== Error Handling ====

// Catch unauthorized errors and return 401
app.use((err, req, res, next) => {
  if (err.name === 'UnauthorizedError') {
    res.status(401).json({ "message": err.name + ": " + err.message });
  } else {
    next(err);
  }
});

// Catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// Error handler (renders error page)
app.use(function(err, req, res, next) {
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;