/**
 * Represents the response received after a successful authentication request.
 * Contains a JWT token string.
 */
export class AuthResponse {
  /** The JWT token string */
  token: string = '';
}
