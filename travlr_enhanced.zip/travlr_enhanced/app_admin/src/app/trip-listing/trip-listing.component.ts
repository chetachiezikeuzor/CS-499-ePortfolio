import {Component, OnInit} from '@angular/core';
import {CommonModule} from "@angular/common";
import {TripCardComponent} from "../trip-card/trip-card.component";
import {Trip} from "../models/trips";
import {TripDataService} from "../services/trip-data.service";
import {Router} from "@angular/router";
import {AuthenticationService} from "../services/authentication";

@Component({
  selector: 'app-trip-listing',
  imports: [CommonModule, TripCardComponent],
  templateUrl: './trip-listing.component.html',
  styleUrls: ['./trip-listing.component.css'],
  standalone: true,
  providers: [TripDataService]
})

/**
 * Component to display a list of trips.
 * Fetches trips from the API and supports navigation to add-trip form.
 */
export class TripListingComponent implements OnInit {
  trips!: Trip[];
  message: string = '';

  constructor(
    private tripDataService: TripDataService,
    private router: Router,
    private authenticationService: AuthenticationService
  ) {}

  private getTrips(): void {
    this.tripDataService.getTrips()
      .subscribe({
        next: (value: any) => {
          this.trips = value;
          if (value.length > 0) {
            this.message = 'There are ' + value.length + ' trips available.';
          } else {
            this.message = 'There were no trips retrieved from the database';
          }
        },
        error: (error: any) => {
          this.message = 'Error retrieving trips: ' + error;
        }
      })
  }

  ngOnInit(): void {
    this.getTrips();
  }

  public isLoggedIn(): boolean {
    return this.authenticationService.isLoggedIn()
  }

  /**
   * Navigates to the add-trip form.
   */
  public addTrip(): void {
    this.router.navigate(['add-trip']);
  }
}
