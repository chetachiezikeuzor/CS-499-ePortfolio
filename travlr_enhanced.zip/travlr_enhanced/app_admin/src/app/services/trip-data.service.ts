import { Inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { lastValueFrom, Observable } from 'rxjs';

import { Trip } from '../models/trips';
import { User } from '../models/user';
import { AuthResponse } from '../models/authresponse';
import { BROWSER_STORAGE } from '../storage';

/**
 * Service for handling all HTTP requests related to trips and authentication.
 * Provides CRUD operations for trips and methods for user login and registration.
 */
@Injectable({
  providedIn: 'root'
})
export class TripDataService {
  private apiBaseUrl = 'http://localhost:3000/api/';
  private tripUrl = `${this.apiBaseUrl}trips/`;

  constructor(
    private http: HttpClient,
    @Inject(BROWSER_STORAGE) private storage: Storage
  ) {}

  /**
   * Fetches all trips from the backend API.
   * @returns Observable emitting an array of Trip objects.
   */
  public getTrips(): Observable<Trip[]> {
    return this.http.get<Trip[]>(`${this.apiBaseUrl}trips`);
  }

  /**
   * Adds a new trip to the backend API.
   * @param formData The Trip data to add.
   * @returns Observable emitting the created Trip object.
   */
  public addTrip(formData: Trip): Observable<Trip> {
    return this.http.post<Trip>(this.tripUrl, formData);
  }

  /**
   * Fetches a specific trip by its code from the backend API.
   * @param tripCode The unique trip code.
   * @returns Observable emitting the Trip object.
   */
  public getTrip(tripCode: string): Observable<Trip> {
    return this.http.get<Trip>(this.tripUrl + tripCode);
  }

  /**
   * Updates an existing trip in the backend API.
   * @param formData The updated Trip data.
   * @returns Observable emitting the updated Trip object.
   */
  public updateTrip(formData: Trip): Observable<Trip> {
    return this.http.put<Trip>(this.tripUrl + formData.code, formData);
  }

  /**
   * Handles HTTP errors for API calls.
   * @param error The error object received.
   * @returns Promise rejected with the error message.
   */
  private handleError(error: any): Promise<any> {
    // Removed console.error for production
    return Promise.reject(error.message || error);
  }

  /**
   * Attempts to log in a user by sending their credentials to the API.
   * @param user The user credentials.
   * @returns Promise emitting the authentication response.
   */
  public login(user: User): Promise<AuthResponse> {
    return this.makeAuthApiCall('login', user);
  }

  /**
   * Attempts to register a new user by sending their info to the API.
   * @param user The user registration info.
   * @returns Promise emitting the authentication response.
   */
  public register(user: User): Promise<AuthResponse> {
    return this.makeAuthApiCall('register', user);
  }

  /**
   * Helper function to perform authentication API calls (login or register).
   * @param urlPath The API path ('login' or 'register').
   * @param user The user credentials or registration info.
   * @returns Promise emitting the authentication response.
   */
  private async makeAuthApiCall(urlPath: string, user: User): Promise<AuthResponse> {
    const url: string = `${this.apiBaseUrl}${urlPath}`;
    try {
      const response = await lastValueFrom(this.http.post<AuthResponse>(url, user));
      return response;
    } catch (error) {
      return this.handleError(error);
    }
  }
}
